package com.nexora.service;

public class NotesGenerator {

    public static String generateNotes(String topic, String subject, String detailLevel) {
        if (topic == null || topic.trim().isEmpty()) {
            return "Please enter a topic to generate notes.";
        }
        if (subject == null || subject.trim().isEmpty()) subject = "General";
        if (detailLevel == null || detailLevel.trim().isEmpty()) detailLevel = "Detailed";

        String prompt = """
Create clear, well-organized study notes for a student.

Subject: %s
Topic: %s
Detail level: %s

Follow this structure:

1. Title
2. Introduction
3. Definition and key concepts
4. Important points
5. Working or explanation, where applicable
6. Examples
7. Advantages and disadvantages, where applicable
8. Important terms
9. Short exam revision points
10. Conclusion

Requirements:
- Use clear and student-friendly language.
- Use headings and subheadings.
- Use bullet points for important information.
- Explain technical terms simply.
- Include relevant examples.
- Avoid unnecessary repetition.
- Do not invent facts or references.
- Make the notes suitable for college exam preparation.
""".formatted(subject, topic, detailLevel);

        return GeminiClient.getAiResponse(
            prompt,
            "You are NEXORA AI, an educational assistant that creates accurate, structured study notes."
        );
    }
}
