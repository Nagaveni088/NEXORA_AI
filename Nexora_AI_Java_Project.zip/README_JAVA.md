# 🎓 NEXORA AI - Student Learning & Career App (Java Edition)

A complete **Java** conversion of the Nexora AI Student Mobile & Web Application, fully replicating all features, UI design, Gemini AI intelligence, and SQLite database storage.

---

## 🚀 Quick Start (1-Click Run)

### Option 1: Double-click or run batch script
Double-click **`run.bat`** (or open PowerShell / Command Prompt in this folder and run):
```cmd
.\run.bat
```
This automatically compiles the Java sources and starts the server at **`http://localhost:8501`**, opening your default web browser.

### Option 2: Command Line (Java 21 / 25)
```cmd
javac -cp "lib/*;." -d bin src/com/nexora/config/*.java src/com/nexora/model/*.java src/com/nexora/db/*.java src/com/nexora/service/*.java src/com/nexora/server/*.java src/com/nexora/Main.java
java -cp "bin;lib/*" com.nexora.Main
```

### Option 3: Apache Maven
```cmd
mvn clean compile exec:java -Dexec.mainClass="com.nexora.Main"
```

---

## 🛠️ Architecture & Conversion Mapping

| Feature | Original Python Module | Java Implementation |
|---|---|---|
| **Entry Point & Web Server** | `app.py` (Streamlit) | `com.nexora.Main`, `AppServer`, `ApiHandler`, `StaticFileHandler` |
| **Styling & UI Design** | `style.css` | `web/index.html`, `web/style.css`, `web/app.js` |
| **Gemini AI Client & Fallback** | `chatbot.py` (`google-genai`) | `com.nexora.service.GeminiClient` (`HttpClient` + multi-model failover) |
| **Database & Auth (PBKDF2)** | `database.py` (sqlite3 + hashlib) | `com.nexora.db.Database` (SQLite JDBC + `PBKDF2WithHmacSHA256`) |
| **Interactive Quiz Lab** | `quiz_generator.py` | `com.nexora.service.QuizGenerator` |
| **PDF Reader & Passage Ranker** | `pdf_reader.py` (`pypdf`) | `com.nexora.service.PdfReaderService` (`Apache PDFBox`) |
| **Study Notes Generator** | `notes_generator.py` | `com.nexora.service.NotesGenerator` |
| **Exam Revision Coach** | `app.py` (Exam Guide submode) | `com.nexora.service.ExamGuideService` |
| **Internship Hub & AI Pitch** | `internships.py` | `com.nexora.service.InternshipService` |
| **LinkedIn Audit & Score** | `linkedin_tracker.py` | `com.nexora.service.LinkedInTracker` |

---

## 🌟 Features Included

1. **100% Free Student Authentication**:
   - Registration with Full Name, Email, Password, College, Branch, Primary Study Interest.
   - Secure password hashing using PBKDF2 with HMAC-SHA256 (200,000 iterations, 32-byte salt) — **fully compatible with existing accounts in `nexora_users.db`**.
   - Auto-login & persistent session tokens.

2. **Student Dashboard**:
   - Header with active scholar badge, college, domain, and 5-day study streak.
   - Real-time stat tiles: AI Queries, Quizzes Taken, Average Quiz Score %, PDFs Studied, Tracked Internships.
   - Weekly learning mastery checklist with interactive checkboxes and progress bar.
   - Quick launch tool buttons.
   - Activity history feed with category badges, timestamps, inputs, and outputs.

3. **AI Tools Hub**:
   - **🤖 AI Mode (Chatbot)**: Subject focus and explanation level dropdowns, quick topic prompt chips, full chat history, Gemini AI streaming responses.
   - **📝 Quiz Lab**: Multiple-choice generator (topic, difficulty, count), interactive MCQ choices (A, B, C, D), real-time score calculation %, breakdown with answers and explanations, saved to database.
   - **📄 PDF Reader & Summarizer**: Drag-and-drop PDF upload, Apache PDFBox text extraction, 1-click actions (Executive Summary, Key Definitions & Formulas, 5 Practice Questions), passage relevance search for grounded Q&A.
   - **🎯 Online Exam Guide**: Tailored 7-day revision blueprint, high-yield weightage, day-by-day roadmap, traps to avoid, formula cheat sheet, sample questions/answers, markdown download.

4. **Student Internship Opportunities Hub**:
   - Curated list of high-paying tech internships (Swiggy, TensorWorks, Zomato, Razorpay, Cred, Postman, Groww, etc.).
   - Search by role, company, or tech stack; filter by category & mode (Remote, Hybrid).
   - "Apply on Portal" direct links.
   - "✉️ Generate AI Pitch" creating customized cold email pitches based on the student's background.
   - "🔖 Save to Tracker" pipeline with status updates ("Interested", "Applied", "Under Review", "Interview Scheduled", "Offer Received").
   - Form to add external job applications.

5. **LinkedIn Profile Tracker & Optimizer**:
   - Algorithmic completeness score (0–100) with detailed checkpoint points.
   - AI Recruiter Audit via Gemini: Recruiter rating, 3 magnetic headlines, rewritten 3-paragraph About summary, high-demand keyword tags, actionable improvement tips.
   - Student growth checklist.

6. **Profile & Settings**:
   - Update full name, college, branch, domain, target role, core skills, LinkedIn profile URL.
