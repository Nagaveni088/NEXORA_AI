package com.nexora.db;

import com.nexora.model.Activity;
import com.nexora.model.Goal;
import com.nexora.model.Internship;
import com.nexora.model.User;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.File;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.sql.*;
import java.util.*;

public class Database {
    private static final String DB_FILE = "nexora_users.db";
    private static final String DB_URL = "jdbc:sqlite:" + DB_FILE;

    static {
        try {
            Class.forName("org.sqlite.JDBC");
            initializeDatabase();
        } catch (ClassNotFoundException e) {
            System.err.println("Warning: SQLite JDBC Driver not found on classpath: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    public static void initializeDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            // Users table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    email TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,
                    salt TEXT NOT NULL,
                    full_name TEXT DEFAULT '',
                    college TEXT DEFAULT '',
                    branch TEXT DEFAULT '',
                    interests TEXT DEFAULT 'Data Science & AI',
                    linkedin_url TEXT DEFAULT '',
                    target_role TEXT DEFAULT 'AI & Data Science Intern',
                    skills TEXT DEFAULT 'Python, Machine Learning, SQL',
                    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
                )
            """);

            // User activity table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS user_activity (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    activity_type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    input_text TEXT DEFAULT '',
                    output_text TEXT DEFAULT '',
                    score REAL DEFAULT NULL,
                    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """);

            // User internships table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS user_internships (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    company TEXT NOT NULL,
                    role TEXT NOT NULL,
                    location TEXT DEFAULT 'Remote',
                    stipend TEXT DEFAULT 'Stipend Provided',
                    status TEXT DEFAULT 'Interested',
                    notes TEXT DEFAULT '',
                    applied_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """);

            // User goals table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS user_goals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    completed INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """);

            // Schema migrations if needed
            checkAndAddColumn(conn, "users", "full_name", "TEXT DEFAULT ''");
            checkAndAddColumn(conn, "users", "college", "TEXT DEFAULT ''");
            checkAndAddColumn(conn, "users", "branch", "TEXT DEFAULT ''");
            checkAndAddColumn(conn, "users", "interests", "TEXT DEFAULT 'Data Science & AI'");
            checkAndAddColumn(conn, "users", "linkedin_url", "TEXT DEFAULT ''");
            checkAndAddColumn(conn, "users", "target_role", "TEXT DEFAULT 'AI & Data Science Intern'");
            checkAndAddColumn(conn, "users", "skills", "TEXT DEFAULT 'Python, Machine Learning, SQL'");
            checkAndAddColumn(conn, "users", "created_at", "TEXT DEFAULT (datetime('now','localtime'))");
            checkAndAddColumn(conn, "user_activity", "score", "REAL DEFAULT NULL");

        } catch (SQLException e) {
            System.err.println("Database initialization error: " + e.getMessage());
        }
    }

    private static void checkAndAddColumn(Connection conn, String table, String column, String colDef) {
        Set<String> existingCols = new HashSet<>();
        try (Statement s = conn.createStatement();
             ResultSet rs = s.executeQuery("PRAGMA table_info(" + table + ")")) {
            while (rs.next()) {
                existingCols.add(rs.getString("name").toLowerCase());
            }
        } catch (SQLException ignored) {}

        if (!existingCols.contains(column.toLowerCase())) {
            try (Statement s = conn.createStatement()) {
                s.execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + colDef);
            } catch (SQLException ignored) {}
        }
    }

    public static String hashPassword(String password, String saltHex) {
        try {
            byte[] salt = HexFormat.of().parseHex(saltHex);
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 200000, 256);
            SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            byte[] hash = skf.generateSecret(spec).getEncoded();
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    public static String generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return HexFormat.of().formatHex(salt);
    }

    public static class AuthResult {
        public final boolean success;
        public final String message;
        public final User user;

        public AuthResult(boolean success, String message, User user) {
            this.success = success;
            this.message = message;
            this.user = user;
        }
    }

    public static AuthResult registerUser(String username, String email, String password,
                                          String fullName, String college, String branch, String interests) {
        username = username != null ? username.trim() : "";
        email = email != null ? email.trim().toLowerCase() : "";
        password = password != null ? password : "";

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            return new AuthResult(false, "Please fill in all required fields (Username, Email, Password).", null);
        }
        if (username.length() < 3) {
            return new AuthResult(false, "Username must be at least 3 characters.", null);
        }
        if (!email.contains("@") || !email.substring(email.indexOf('@')).contains(".")) {
            return new AuthResult(false, "Please enter a valid email address.", null);
        }
        if (password.length() < 6) {
            return new AuthResult(false, "Password must be at least 6 characters.", null);
        }

        String salt = generateSalt();
        String passwordHash = hashPassword(password, salt);
        String finalFullName = (fullName != null && !fullName.trim().isEmpty()) ? fullName.trim() : username;
        String finalCollege = college != null ? college.trim() : "";
        String finalBranch = branch != null ? branch.trim() : "";
        String finalInterests = (interests != null && !interests.trim().isEmpty()) ? interests.trim() : "Data Science & AI";

        String insertSql = """
            INSERT INTO users (username, email, password_hash, salt, full_name, college, branch, interests)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, username);
            ps.setString(2, email);
            ps.setString(3, passwordHash);
            ps.setString(4, salt);
            ps.setString(5, finalFullName);
            ps.setString(6, finalCollege);
            ps.setString(7, finalBranch);
            ps.setString(8, finalInterests);
            ps.executeUpdate();

            int userId = 0;
            try (Statement s = conn.createStatement();
                 ResultSet rs = s.executeQuery("SELECT last_insert_rowid()")) {
                if (rs.next()) {
                    userId = rs.getInt(1);
                }
            }
            if (userId <= 0) {
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        userId = generatedKeys.getInt(1);
                    }
                }
            }

            // Seed default weekly learning goals
            String[] defaultGoals = {
                "Ask AI Tutor 1 concept question",
                "Complete a 5-question Quiz in your domain",
                "Upload a PDF or lecture note to review",
                "Review LinkedIn Profile & headline score",
                "Check matching internship opportunities"
            };

            String goalSql = "INSERT INTO user_goals (user_id, title, completed) VALUES (?, ?, 0)";
            try (PreparedStatement gps = conn.prepareStatement(goalSql)) {
                for (String g : defaultGoals) {
                    gps.setInt(1, userId);
                    gps.setString(2, g);
                    gps.addBatch();
                }
                gps.executeBatch();
            }

            User user = getUserById(userId);
            if (user == null) {
                user = authenticateUser(username, password);
            }
            return new AuthResult(true, "Account created successfully! Welcome to Nexora AI Student App.", user);

        } catch (SQLException e) {
            String err = e.getMessage().toLowerCase();
            if (err.contains("username") || err.contains("unique constraint failed: users.username")) {
                return new AuthResult(false, "That username is already taken. Please choose another.", null);
            } else if (err.contains("email") || err.contains("unique constraint failed: users.email")) {
                return new AuthResult(false, "That email is already registered. Please sign in.", null);
            }
            return new AuthResult(false, "An account with these details already exists.", null);
        }
    }

    public static User authenticateUser(String usernameOrEmail, String password) {
        if (usernameOrEmail == null || usernameOrEmail.isBlank() || password == null || password.isBlank()) {
            return null;
        }
        usernameOrEmail = usernameOrEmail.trim();

        String sql = """
            SELECT * FROM users
            WHERE username = ? COLLATE NOCASE
               OR email = ? COLLATE NOCASE
        """;

        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, usernameOrEmail);
            ps.setString(2, usernameOrEmail);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String salt = rs.getString("salt");
                    String storedHash = rs.getString("password_hash");
                    String inputHash = hashPassword(password, salt);

                    if (inputHash.equalsIgnoreCase(storedHash)) {
                        return mapUser(rs);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Authentication error: " + e.getMessage());
        }
        return null;
    }

    public static User getUserById(int userId) {
        if (userId <= 0) return null;
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapUser(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("getUserById error: " + e.getMessage());
        }
        return null;
    }

    public static boolean updateUserProfile(int userId, String fullName, String college, String branch,
                                           String interests, String linkedinUrl, String targetRole, String skills) {
        String sql = """
            UPDATE users
            SET full_name = ?, college = ?, branch = ?, interests = ?,
                linkedin_url = ?, target_role = ?, skills = ?
            WHERE id = ?
        """;
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, fullName != null ? fullName.trim() : "");
            ps.setString(2, college != null ? college.trim() : "");
            ps.setString(3, branch != null ? branch.trim() : "");
            ps.setString(4, interests != null ? interests.trim() : "Data Science & AI");
            ps.setString(5, linkedinUrl != null ? linkedinUrl.trim() : "");
            ps.setString(6, targetRole != null ? targetRole.trim() : "AI & Data Science Intern");
            ps.setString(7, skills != null ? skills.trim() : "Python, Machine Learning, SQL");
            ps.setInt(8, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("updateUserProfile error: " + e.getMessage());
            return false;
        }
    }

    public static void logActivity(int userId, String activityType, String title,
                                   String inputText, String outputText, Double score) {
        if (userId <= 0) return;
        String sql = """
            INSERT INTO user_activity (user_id, activity_type, title, input_text, output_text, score)
            VALUES (?, ?, ?, ?, ?, ?)
        """;
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, activityType != null ? activityType : "Study");
            ps.setString(3, title != null ? title : "");
            ps.setString(4, inputText != null ? inputText : "");
            ps.setString(5, outputText != null ? outputText : "");
            if (score != null) {
                ps.setDouble(6, score);
            } else {
                ps.setNull(6, Types.REAL);
            }
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("logActivity error: " + e.getMessage());
        }
    }

    public static List<Activity> getUserActivity(int userId, int limit) {
        List<Activity> list = new ArrayList<>();
        if (userId <= 0) return list;
        String sql = """
            SELECT id, user_id, activity_type, title, input_text, output_text, score, created_at
            FROM user_activity
            WHERE user_id = ?
            ORDER BY id DESC
            LIMIT ?
        """;
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, limit > 0 ? limit : 50);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Double score = rs.getObject("score") != null ? rs.getDouble("score") : null;
                    list.add(new Activity(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("activity_type"),
                        rs.getString("title"),
                        rs.getString("input_text"),
                        rs.getString("output_text"),
                        score,
                        rs.getString("created_at")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("getUserActivity error: " + e.getMessage());
        }
        return list;
    }

    public static Map<String, Integer> getActivityCounts(int userId) {
        Map<String, Integer> counts = new HashMap<>();
        if (userId <= 0) return counts;
        String sql = """
            SELECT activity_type, COUNT(*) as cnt
            FROM user_activity
            WHERE user_id = ?
            GROUP BY activity_type
        """;
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    counts.put(rs.getString("activity_type"), rs.getInt("cnt"));
                }
            }
        } catch (SQLException e) {
            System.err.println("getActivityCounts error: " + e.getMessage());
        }
        return counts;
    }

    public static double getAverageQuizScore(int userId) {
        if (userId <= 0) return 0.0;
        String sql = """
            SELECT AVG(score) as avg_score
            FROM user_activity
            WHERE user_id = ? AND activity_type = 'Quiz' AND score IS NOT NULL
        """;
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    double val = rs.getDouble("avg_score");
                    if (!rs.wasNull()) {
                        return Math.round(val * 10.0) / 10.0;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("getAverageQuizScore error: " + e.getMessage());
        }
        return 0.0;
    }

    public static void clearUserActivity(int userId) {
        if (userId <= 0) return;
        String sql = "DELETE FROM user_activity WHERE user_id = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("clearUserActivity error: " + e.getMessage());
        }
    }

    public static List<Goal> getUserGoals(int userId) {
        List<Goal> list = new ArrayList<>();
        if (userId <= 0) return list;
        String sql = "SELECT id, user_id, title, completed, created_at FROM user_goals WHERE user_id = ? ORDER BY id ASC";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Goal(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("title"),
                        rs.getInt("completed") == 1,
                        rs.getString("created_at")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("getUserGoals error: " + e.getMessage());
        }
        return list;
    }

    public static void toggleUserGoal(int goalId, boolean completed) {
        String sql = "UPDATE user_goals SET completed = ? WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, completed ? 1 : 0);
            ps.setInt(2, goalId);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("toggleUserGoal error: " + e.getMessage());
        }
    }

    public static void addUserGoal(int userId, String title) {
        if (userId <= 0 || title == null || title.isBlank()) return;
        String sql = "INSERT INTO user_goals (user_id, title, completed) VALUES (?, ?, 0)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, title.trim());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("addUserGoal error: " + e.getMessage());
        }
    }

    public static List<Internship> getUserInternships(int userId) {
        List<Internship> list = new ArrayList<>();
        if (userId <= 0) return list;
        String sql = """
            SELECT id, user_id, company, role, location, stipend, status, notes, applied_at
            FROM user_internships
            WHERE user_id = ?
            ORDER BY id DESC
        """;
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Internship in = new Internship();
                    in.setDbId(rs.getInt("id"));
                    in.setUserId(rs.getInt("user_id"));
                    in.setCompany(rs.getString("company"));
                    in.setTitle(rs.getString("role"));
                    in.setLocation(rs.getString("location"));
                    in.setStipend(rs.getString("stipend"));
                    in.setStatus(rs.getString("status"));
                    in.setNotes(rs.getString("notes"));
                    in.setAppliedAt(rs.getString("applied_at"));
                    list.add(in);
                }
            }
        } catch (SQLException e) {
            System.err.println("getUserInternships error: " + e.getMessage());
        }
        return list;
    }

    public static boolean saveUserInternship(int userId, String company, String role,
                                            String location, String stipend, String status, String notes) {
        if (userId <= 0 || company == null || company.isBlank()) return false;
        company = company.trim();
        role = role != null ? role.trim() : "Intern";
        location = location != null ? location.trim() : "Remote";
        stipend = stipend != null ? stipend.trim() : "Stipend Provided";
        status = status != null ? status.trim() : "Interested";
        notes = notes != null ? notes.trim() : "";

        String checkSql = "SELECT id FROM user_internships WHERE user_id = ? AND company = ? AND role = ?";
        try (Connection conn = getConnection(); PreparedStatement cps = conn.prepareStatement(checkSql)) {
            cps.setInt(1, userId);
            cps.setString(2, company);
            cps.setString(3, role);
            try (ResultSet rs = cps.executeQuery()) {
                if (rs.next()) {
                    int existingId = rs.getInt("id");
                    String updSql = "UPDATE user_internships SET status = ?, notes = ? WHERE id = ?";
                    try (PreparedStatement ups = conn.prepareStatement(updSql)) {
                        ups.setString(1, status);
                        ups.setString(2, notes);
                        ups.setInt(3, existingId);
                        ups.executeUpdate();
                    }
                    return true;
                }
            }

            String insSql = """
                INSERT INTO user_internships (user_id, company, role, location, stipend, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """;
            try (PreparedStatement ips = conn.prepareStatement(insSql)) {
                ips.setInt(1, userId);
                ips.setString(2, company);
                ips.setString(3, role);
                ips.setString(4, location);
                ips.setString(5, stipend);
                ips.setString(6, status);
                ips.setString(7, notes);
                ips.executeUpdate();
            }
            return true;
        } catch (SQLException e) {
            System.err.println("saveUserInternship error: " + e.getMessage());
            return false;
        }
    }

    public static void deleteUserInternship(int internshipId, int userId) {
        String sql = "DELETE FROM user_internships WHERE id = ? AND user_id = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, internshipId);
            ps.setInt(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("deleteUserInternship error: " + e.getMessage());
        }
    }

    private static String getSafeString(ResultSet rs, String colName) {
        try {
            String val = rs.getString(colName);
            return val != null ? val : "";
        } catch (SQLException e) {
            return "";
        }
    }

    private static User mapUser(ResultSet rs) throws SQLException {
        return new User(
            rs.getInt("id"),
            getSafeString(rs, "username"),
            getSafeString(rs, "email"),
            getSafeString(rs, "password_hash"),
            getSafeString(rs, "salt"),
            getSafeString(rs, "full_name"),
            getSafeString(rs, "college"),
            getSafeString(rs, "branch"),
            getSafeString(rs, "interests"),
            getSafeString(rs, "linkedin_url"),
            getSafeString(rs, "target_role"),
            getSafeString(rs, "skills"),
            getSafeString(rs, "created_at")
        );
    }
}
