@echo off
echo ===================================================
echo  Compiling NEXORA AI Student App (Java Edition)
echo ===================================================

if not exist "bin" mkdir bin

echo Compiling Java source files...
javac -cp "lib/*;." -d bin src/com/nexora/config/*.java src/com/nexora/model/*.java src/com/nexora/db/*.java src/com/nexora/service/*.java src/com/nexora/server/*.java src/com/nexora/Main.java

if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Compilation failed.
    pause
    exit /b %ERRORLEVEL%
)

echo [SUCCESS] Compilation successful! Class files are in 'bin/'.
