package com.nexora.model;

import java.util.List;

public class Internship {
    private String id;
    private String title;
    private String company;
    private String emoji;
    private String category;
    private String location;
    private String stipend;
    private String duration;
    private String mode;
    private List<String> skills;
    private String description;
    private String applyUrl;

    // Tracked internship fields
    private Integer dbId;
    private Integer userId;
    private String status; // "Interested", "Applied", "Under Review", "Interview Scheduled", "Offer Received"
    private String notes;
    private String appliedAt;

    public Internship() {}

    public Internship(String id, String title, String company, String emoji, String category,
                      String location, String stipend, String duration, String mode,
                      List<String> skills, String description, String applyUrl) {
        this.id = id;
        this.title = title;
        this.company = company;
        this.emoji = emoji;
        this.category = category;
        this.location = location;
        this.stipend = stipend;
        this.duration = duration;
        this.mode = mode;
        this.skills = skills;
        this.description = description;
        this.applyUrl = applyUrl;
        this.status = "Interested";
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }

    public String getEmoji() { return emoji; }
    public void setEmoji(String emoji) { this.emoji = emoji; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getStipend() { return stipend; }
    public void setStipend(String stipend) { this.stipend = stipend; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }

    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }

    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getApplyUrl() { return applyUrl; }
    public void setApplyUrl(String applyUrl) { this.applyUrl = applyUrl; }

    public Integer getDbId() { return dbId; }
    public void setDbId(Integer dbId) { this.dbId = dbId; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getAppliedAt() { return appliedAt; }
    public void setAppliedAt(String appliedAt) { this.appliedAt = appliedAt; }
}
