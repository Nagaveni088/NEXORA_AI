package com.nexora.service;

import com.nexora.config.Config;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class GeminiClient {
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(15))
        .build();

    public static String getAiResponse(String prompt) {
        return getAiResponse(prompt, null);
    }

    public static String getAiResponse(String prompt, String systemInstruction) {
        String apiKey = Config.getGeminiApiKey();
        if (apiKey == null || apiKey.isBlank()) {
            return "Gemini API key is missing. Please check GEMINI_API_KEY in your .env file.";
        }

        if (prompt == null || prompt.trim().isEmpty()) {
            return "Please enter a question or topic.";
        }

        Exception lastError = null;

        for (String model : Config.MODEL_CANDIDATES) {
            for (int attempt = 0; attempt < 2; attempt++) {
                try {
                    String url = "https://generativelanguage.googleapis.com/v1beta/models/"
                        + model + ":generateContent?key=" + apiKey;

                    StringBuilder jsonBuilder = new StringBuilder();
                    jsonBuilder.append("{\n");
                    jsonBuilder.append("  \"contents\": [\n");
                    jsonBuilder.append("    {\n");
                    jsonBuilder.append("      \"parts\": [\n");
                    jsonBuilder.append("        {\"text\": ").append(jsonEscape(prompt)).append("}\n");
                    jsonBuilder.append("      ]\n");
                    jsonBuilder.append("    }\n");
                    jsonBuilder.append("  ]");

                    if (systemInstruction != null && !systemInstruction.isBlank()) {
                        jsonBuilder.append(",\n  \"systemInstruction\": {\n");
                        jsonBuilder.append("    \"parts\": [\n");
                        jsonBuilder.append("      {\"text\": ").append(jsonEscape(systemInstruction)).append("}\n");
                        jsonBuilder.append("    ]\n");
                        jsonBuilder.append("  }\n");
                    }
                    jsonBuilder.append("\n}");

                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .timeout(Duration.ofSeconds(60))
                        .POST(HttpRequest.BodyPublishers.ofString(jsonBuilder.toString()))
                        .build();

                    HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                    int status = response.statusCode();

                    if (status >= 200 && status < 300) {
                        String text = extractTextFromGeminiResponse(response.body());
                        if (text != null && !text.isBlank()) {
                            return text.trim();
                        }
                    } else {
                        String body = response.body();
                        lastError = new RuntimeException("HTTP " + status + ": " + (body.length() > 200 ? body.substring(0, 200) : body));
                        if (status == 404 || status == 503 || body.contains("NOT_FOUND") || body.contains("UNAVAILABLE")) {
                            break; // Skip to next candidate model
                        }
                    }
                } catch (Exception e) {
                    lastError = e;
                    String msg = e.getMessage() != null ? e.getMessage() : "";
                    if (msg.contains("404") || msg.contains("503") || msg.contains("NOT_FOUND") || msg.contains("UNAVAILABLE")) {
                        break;
                    }
                }

                try {
                    Thread.sleep(500);
                } catch (InterruptedException ignored) {}
            }
        }

        return "Unable to generate AI response currently. Please try again in a few moments. (Details: " +
            (lastError != null ? lastError.getMessage() : "Unknown error") + ")";
    }

    public static String extractTextFromGeminiResponse(String responseJson) {
        if (responseJson == null) return "";
        try {
            // Find "candidates"
            int candIdx = responseJson.indexOf("\"candidates\"");
            if (candIdx == -1) return "";

            // Find "text" inside candidates
            int textKeyIdx = responseJson.indexOf("\"text\":", candIdx);
            if (textKeyIdx == -1) return "";

            int valStart = responseJson.indexOf("\"", textKeyIdx + 7);
            if (valStart == -1) return "";

            StringBuilder sb = new StringBuilder();
            boolean escaped = false;
            for (int i = valStart + 1; i < responseJson.length(); i++) {
                char c = responseJson.charAt(i);
                if (escaped) {
                    switch (c) {
                        case 'n' -> sb.append('\n');
                        case 'r' -> sb.append('\r');
                        case 't' -> sb.append('\t');
                        case 'b' -> sb.append('\b');
                        case 'f' -> sb.append('\f');
                        case '"' -> sb.append('"');
                        case '\\' -> sb.append('\\');
                        case 'u' -> {
                            if (i + 4 < responseJson.length()) {
                                String hex = responseJson.substring(i + 1, i + 5);
                                try {
                                    sb.append((char) Integer.parseInt(hex, 16));
                                    i += 4;
                                } catch (NumberFormatException e) {
                                    sb.append("\\u");
                                }
                            } else {
                                sb.append("\\u");
                            }
                        }
                        default -> sb.append(c);
                    }
                    escaped = false;
                } else if (c == '\\') {
                    escaped = true;
                } else if (c == '"') {
                    break;
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static String jsonEscape(String s) {
        if (s == null) return "\"\"";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < ' ') {
                        String t = "000" + Integer.toHexString(c);
                        sb.append("\\u").append(t.substring(t.length() - 4));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        sb.append("\"");
        return sb.toString();
    }
}
