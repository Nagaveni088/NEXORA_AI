package com.nexora.service;

public class ExamGuideService {

    public static String generateExamGuide(String examName, String examDays, String examType, String challengingTopics) {
        if (examName == null || examName.isBlank()) {
            return "Please enter your exam or subject name.";
        }
        if (examDays == null || examDays.isBlank()) examDays = "7 Days (Standard Crash Course)";
        if (examType == null || examType.isBlank()) examType = "Semester University Exam (Theory + Coding)";
        if (challengingTopics == null || challengingTopics.isBlank()) challengingTopics = "All core topics";

        String prompt = """
Create an intensive, high-yield Exam Preparation Blueprint for a student:

Exam Name: %s
Format: %s
Timeline: %s
Challenging Topics: %s

Provide a structured guide covering:
1. 🎯 High-Yield Weightage Analysis (Top 5 topics most likely to carry 70%% of marks)
2. 📅 Day-by-Day Revision Roadmap (Specific hourly / daily targets)
3. ⚠️ Common Traps & Exam Hall Pitfalls to Avoid
4. 🧠 Quick Formula & Concept Memory Cheat Sheet
5. 📝 3 Predicted Master Exam Questions with High-Scoring Sample Answers
""".formatted(examName, examType, examDays, challengingTopics);

        return GeminiClient.getAiResponse(
            prompt,
            "You are a veteran college professor and exam strategist. Provide rigorous, practical revision frameworks."
        );
    }
}
