package com.nexora;

import com.nexora.config.Config;
import com.nexora.db.Database;
import com.nexora.server.AppServer;

import java.awt.Desktop;
import java.net.URI;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Initializing Nexora AI Student App...");

            // Initialize SQLite Database
            Database.initializeDatabase();

            int port = Config.getPort();
            AppServer server = new AppServer(port);
            server.start();

            // Try to open default browser automatically
            try {
                if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                    Desktop.getDesktop().browse(new URI("http://localhost:" + port));
                }
            } catch (Exception ignored) {}

        } catch (Exception e) {
            System.err.println("Failed to start server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
