package com.nexora.service;

import java.util.*;

public class LinkedInTracker {

    public static class ScoreResult {
        public final int score;
        public final List<String> feedbackItems;

        public ScoreResult(int score, List<String> feedbackItems) {
            this.score = score;
            this.feedbackItems = feedbackItems;
        }
    }

    public static ScoreResult calculateScore(String headline, String summary, String skills,
                                             String experience, String profileUrl) {
        int score = 0;
        List<String> feedback = new ArrayList<>();

        // Profile URL check
        if (profileUrl != null && profileUrl.contains("linkedin.com/in/")) {
            score += 15;
            feedback.add("Custom LinkedIn profile URL provided (+15 pts)");
        } else {
            feedback.add("Add your official LinkedIn profile URL (+15 pts)");
        }

        // Headline check
        headline = headline != null ? headline.trim() : "";
        if (headline.length() >= 40) {
            score += 25;
            feedback.add("Detailed, keyword-rich headline (+25 pts)");
        } else if (headline.length() >= 15) {
            score += 15;
            feedback.add("Headline is present but could include stronger keywords (+15 pts)");
        } else {
            feedback.add("Headline is too short or missing (+0 pts)");
        }

        // Summary check
        summary = summary != null ? summary.trim() : "";
        if (summary.length() >= 200) {
            score += 25;
            feedback.add("Comprehensive About section with story & goals (+25 pts)");
        } else if (summary.length() >= 60) {
            score += 15;
            feedback.add("About section is brief; consider adding projects and ambitions (+15 pts)");
        } else {
            feedback.add("About summary is missing or too brief (+0 pts)");
        }

        // Skills check
        skills = skills != null ? skills.trim() : "";
        String[] skillsArr = skills.isEmpty() ? new String[0] : skills.split(",");
        int skillCount = 0;
        for (String s : skillsArr) {
            if (!s.trim().isEmpty()) skillCount++;
        }

        if (skillCount >= 5) {
            score += 20;
            feedback.add(skillCount + " key skills listed (+20 pts)");
        } else if (skillCount >= 2) {
            score += 10;
            feedback.add("A few skills listed; add at least 5-10 core technical skills (+10 pts)");
        } else {
            feedback.add("Add top technical & soft skills (+0 pts)");
        }

        // Experience / Target role check
        experience = experience != null ? experience.trim() : "";
        if (experience.length() >= 50) {
            score += 15;
            feedback.add("Projects or internship experience listed (+15 pts)");
        } else {
            feedback.add("Add key academic projects or internships (+0 pts)");
        }

        return new ScoreResult(Math.min(100, score), feedback);
    }

    public static String analyzeProfileAi(String headline, String summary, String skills,
                                          String targetRole, String interest) {
        if (interest == null || interest.isBlank()) interest = "Data Science & AI";
        if (targetRole == null || targetRole.isBlank()) targetRole = "AI & Data Science Intern";

        String prompt = """
Act as a Senior Tech Recruiter and LinkedIn Optimization Specialist.
Review and optimize the following student profile:

Target Career Interest: %s
Target Job/Internship Role: %s
Current Headline: %s
Current About/Summary: %s
Skills Listed: %s

Provide a comprehensive, high-impact review formatted as JSON with these exact keys:
{
  "recruiter_rating": "Fair / Good / Excellent",
  "score": 75,
  "headline_options": [
    "Catchy Headline Option 1 (Title | Key Skills | Aspirations)",
    "Catchy Headline Option 2 (Action-driven & value-focused)",
    "Catchy Headline Option 3 (Industry-standard recruiter magnetic)"
  ],
  "improved_summary": "A polished, engaging 3-paragraph LinkedIn About section written in first person. Highlight passions, projects, tech stack, and what opportunities they are seeking.",
  "recommended_keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5", "keyword6"],
  "top_improvements": [
    "Specific actionable tip 1",
    "Specific actionable tip 2",
    "Specific actionable tip 3"
  ]
}

Return ONLY valid JSON.
""".formatted(
            interest,
            targetRole,
            headline != null && !headline.isBlank() ? headline : "Not provided",
            summary != null && !summary.isBlank() ? summary : "Not provided",
            skills != null && !skills.isBlank() ? skills : "Not provided"
        );

        return GeminiClient.getAiResponse(
            prompt,
            "You are an expert tech recruiter and LinkedIn career coach. Provide strict valid JSON only."
        );
    }
}
