package com.nexora.server;

import com.nexora.config.Config;
import com.sun.net.httpserver.HttpServer;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;

public class AppServer {
    private final HttpServer server;
    private final int port;

    public AppServer(int port) throws IOException {
        this.port = port;
        this.server = HttpServer.create(new InetSocketAddress(port), 0);
        this.server.setExecutor(Executors.newFixedThreadPool(20));

        // Register API endpoints
        this.server.createContext("/api/", new ApiHandler());

        // Register Static files
        File webDir = new File("web");
        this.server.createContext("/", new StaticFileHandler(webDir));
    }

    public void start() {
        server.start();
        System.out.println("=================================================");
        System.out.println(" 🎓 NEXORA AI Student App (Java Edition)");
        System.out.println(" Server running at: http://localhost:" + port);
        System.out.println("=================================================");
    }

    public void stop() {
        server.stop(0);
    }

    public int getPort() {
        return port;
    }
}
