package com.nexora.model;

import java.util.Map;

public class QuizQuestion {
    private String question;
    private Map<String, String> options; // "A" -> "...", "B" -> "..."
    private String answer; // "A", "B", "C", "D"
    private String explanation;

    public QuizQuestion() {}

    public QuizQuestion(String question, Map<String, String> options, String answer, String explanation) {
        this.question = question;
        this.options = options;
        this.answer = answer;
        this.explanation = explanation;
    }

    public String getQuestion() { return question; }
    public void setQuestion(String question) { this.question = question; }

    public Map<String, String> getOptions() { return options; }
    public void setOptions(Map<String, String> options) { this.options = options; }

    public String getAnswer() { return answer; }
    public void setAnswer(String answer) { this.answer = answer; }

    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }
}
