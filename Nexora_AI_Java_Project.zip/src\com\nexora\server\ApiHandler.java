package com.nexora.server;

import com.nexora.db.Database;
import com.nexora.model.*;
import com.nexora.service.*;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ApiHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        // Enable CORS
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type, Authorization");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        String path = exchange.getRequestURI().getPath();
        String method = exchange.getRequestMethod().toUpperCase();
        User currentUser = authenticateRequest(exchange);

        try {
            switch (path) {
                // AUTH
                case "/api/auth/register" -> handleRegister(exchange);
                case "/api/auth/login" -> handleLogin(exchange);
                case "/api/auth/logout" -> handleLogout(exchange);
                case "/api/user/me" -> handleGetMe(exchange, currentUser);
                case "/api/user/profile" -> handleUpdateProfile(exchange, currentUser);

                // DASHBOARD
                case "/api/dashboard" -> handleGetDashboard(exchange, currentUser);
                case "/api/goals/toggle" -> handleToggleGoal(exchange, currentUser);
                case "/api/goals/add" -> handleAddGoal(exchange, currentUser);
                case "/api/activity/clear" -> handleClearActivity(exchange, currentUser);

                // AI TOOLS HUB
                case "/api/tutor/chat" -> handleTutorChat(exchange, currentUser);
                case "/api/quiz/generate" -> handleQuizGenerate(exchange);
                case "/api/quiz/submit" -> handleQuizSubmit(exchange, currentUser);
                case "/api/pdf/upload" -> handlePdfUpload(exchange);
                case "/api/pdf/action" -> handlePdfAction(exchange, currentUser);
                case "/api/exam/generate" -> handleExamGenerate(exchange, currentUser);

                // LINKEDIN
                case "/api/linkedin/score" -> handleLinkedInScore(exchange);
                case "/api/linkedin/audit" -> handleLinkedInAudit(exchange, currentUser);

                // INTERNSHIPS
                case "/api/internships" -> handleGetInternships(exchange);
                case "/api/internships/pitch" -> handleInternshipPitch(exchange, currentUser);
                case "/api/internships/tracked" -> handleGetTrackedInternships(exchange, currentUser);
                case "/api/internships/track" -> handleTrackInternship(exchange, currentUser);
                case "/api/internships/delete" -> handleDeleteInternship(exchange, currentUser);

                default -> sendJson(exchange, 404, "{\"error\": \"Endpoint not found: " + path + "\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendJson(exchange, 500, "{\"error\": " + jsonEscape(e.getMessage() != null ? e.getMessage() : "Internal Server Error") + "}");
        }
    }

    private User authenticateRequest(HttpExchange exchange) {
        String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
        String token = null;
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7).trim();
        } else {
            String cookieHeader = exchange.getRequestHeaders().getFirst("Cookie");
            if (cookieHeader != null) {
                for (String c : cookieHeader.split(";")) {
                    String[] pair = c.trim().split("=", 2);
                    if (pair.length == 2 && "session_token".equals(pair[0].trim())) {
                        token = pair[1].trim();
                        break;
                    }
                }
            }
        }
        return SessionManager.getUser(token);
    }

    // --- AUTH HANDLERS ---
    private void handleRegister(HttpExchange exchange) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);

        String username = json.getOrDefault("username", "");
        String email = json.getOrDefault("email", "");
        String password = json.getOrDefault("password", "");
        String fullName = json.getOrDefault("fullName", "");
        String college = json.getOrDefault("college", "");
        String branch = json.getOrDefault("branch", "");
        String interests = json.getOrDefault("interests", "Data Science & AI");

        Database.AuthResult res = Database.registerUser(username, email, password, fullName, college, branch, interests);
        if (res.success && res.user != null) {
            String token = SessionManager.createSession(res.user.getId());
            exchange.getResponseHeaders().add("Set-Cookie", "session_token=" + token + "; Path=/; HttpOnly; SameSite=Lax");
            sendJson(exchange, 200, """
                {
                  "success": true,
                  "message": %s,
                  "token": "%s",
                  "user": %s
                }
            """.formatted(jsonEscape(res.message), token, userToJson(res.user)));
        } else {
            sendJson(exchange, 400, """
                {
                  "success": false,
                  "message": %s
                }
            """.formatted(jsonEscape(res.message)));
        }
    }

    private void handleLogin(HttpExchange exchange) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);

        String identity = json.getOrDefault("usernameOrEmail", "");
        String password = json.getOrDefault("password", "");

        User user = Database.authenticateUser(identity, password);
        if (user != null) {
            String token = SessionManager.createSession(user.getId());
            exchange.getResponseHeaders().add("Set-Cookie", "session_token=" + token + "; Path=/; HttpOnly; SameSite=Lax");
            sendJson(exchange, 200, """
                {
                  "success": true,
                  "message": "Welcome back!",
                  "token": "%s",
                  "user": %s
                }
            """.formatted(token, userToJson(user)));
        } else {
            sendJson(exchange, 401, """
                {
                  "success": false,
                  "message": "Invalid username/email or password. Please try again."
                }
            """);
        }
    }

    private void handleLogout(HttpExchange exchange) throws IOException {
        String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            SessionManager.removeSession(authHeader.substring(7).trim());
        }
        exchange.getResponseHeaders().add("Set-Cookie", "session_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
        sendJson(exchange, 200, "{\"success\": true}");
    }

    private void handleGetMe(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        User refreshed = Database.getUserById(currentUser.getId());
        sendJson(exchange, 200, userToJson(refreshed != null ? refreshed : currentUser));
    }

    private void handleUpdateProfile(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);

        boolean ok = Database.updateUserProfile(
            currentUser.getId(),
            json.getOrDefault("fullName", ""),
            json.getOrDefault("college", ""),
            json.getOrDefault("branch", ""),
            json.getOrDefault("interests", "Data Science & AI"),
            json.getOrDefault("linkedinUrl", ""),
            json.getOrDefault("targetRole", "AI & Data Science Intern"),
            json.getOrDefault("skills", "Python, Machine Learning, SQL")
        );

        if (ok) {
            User updated = Database.getUserById(currentUser.getId());
            sendJson(exchange, 200, """
                {
                  "success": true,
                  "message": "Profile updated successfully!",
                  "user": %s
                }
            """.formatted(userToJson(updated)));
        } else {
            sendJson(exchange, 400, "{\"success\": false, \"message\": \"Failed to update profile.\"}");
        }
    }

    // --- DASHBOARD HANDLERS ---
    private void handleGetDashboard(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        int userId = currentUser.getId();
        Map<String, Integer> counts = Database.getActivityCounts(userId);
        int aiCount = counts.getOrDefault("AI Tutor", 0);
        int quizCount = counts.getOrDefault("Quiz", 0);
        int pdfCount = counts.getOrDefault("PDF Study", 0);
        double avgQuizScore = Database.getAverageQuizScore(userId);
        List<Internship> tracked = Database.getUserInternships(userId);
        List<Goal> goals = Database.getUserGoals(userId);
        List<Activity> activities = Database.getUserActivity(userId, 20);

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"aiCount\": ").append(aiCount).append(",\n");
        sb.append("  \"quizCount\": ").append(quizCount).append(",\n");
        sb.append("  \"avgQuizScore\": ").append(avgQuizScore).append(",\n");
        sb.append("  \"pdfCount\": ").append(pdfCount).append(",\n");
        sb.append("  \"internshipCount\": ").append(tracked.size()).append(",\n");

        sb.append("  \"goals\": [");
        for (int i = 0; i < goals.size(); i++) {
            Goal g = goals.get(i);
            if (i > 0) sb.append(", ");
            sb.append("{\"id\": ").append(g.getId())
              .append(", \"title\": ").append(jsonEscape(g.getTitle()))
              .append(", \"completed\": ").append(g.isCompleted()).append("}");
        }
        sb.append("],\n");

        sb.append("  \"activities\": [");
        for (int i = 0; i < activities.size(); i++) {
            Activity a = activities.get(i);
            if (i > 0) sb.append(", ");
            sb.append("{\"id\": ").append(a.getId())
              .append(", \"activityType\": ").append(jsonEscape(a.getActivityType()))
              .append(", \"title\": ").append(jsonEscape(a.getTitle()))
              .append(", \"inputText\": ").append(jsonEscape(a.getInputText()))
              .append(", \"outputText\": ").append(jsonEscape(a.getOutputText()))
              .append(", \"score\": ").append(a.getScore() != null ? a.getScore() : "null")
              .append(", \"createdAt\": ").append(jsonEscape(a.getCreatedAt()))
              .append("}");
        }
        sb.append("]\n");
        sb.append("}");

        sendJson(exchange, 200, sb.toString());
    }

    private void handleToggleGoal(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        int goalId = Integer.parseInt(json.getOrDefault("goalId", "0"));
        boolean completed = Boolean.parseBoolean(json.getOrDefault("completed", "false"));

        Database.toggleUserGoal(goalId, completed);
        sendJson(exchange, 200, "{\"success\": true}");
    }

    private void handleAddGoal(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String title = json.getOrDefault("title", "");
        if (!title.isBlank()) {
            Database.addUserGoal(currentUser.getId(), title);
        }
        sendJson(exchange, 200, "{\"success\": true}");
    }

    private void handleClearActivity(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        Database.clearUserActivity(currentUser.getId());
        sendJson(exchange, 200, "{\"success\": true}");
    }

    // --- AI TOOLS HUB ---
    private void handleTutorChat(HttpExchange exchange, User currentUser) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String prompt = json.getOrDefault("prompt", "");
        String subject = json.getOrDefault("subject", "Computer Science & AI");
        String level = json.getOrDefault("level", "Undergraduate / College");

        String systemInstruction = "You are NEXORA AI, an expert college tutor specializing in " + subject +
            ". Target audience level: " + level +
            ". Provide clear, structured explanations with bullet points, code snippets if applicable, and real-world examples.";

        String reply = GeminiClient.getAiResponse(prompt, systemInstruction);

        if (currentUser != null && !prompt.isBlank()) {
            Database.logActivity(
                currentUser.getId(),
                "AI Tutor",
                "Asked: " + (prompt.length() > 40 ? prompt.substring(0, 40) + "..." : prompt),
                prompt,
                reply.length() > 400 ? reply.substring(0, 400) : reply,
                null
            );
        }

        sendJson(exchange, 200, "{\"reply\": " + jsonEscape(reply) + "}");
    }

    private void handleQuizGenerate(HttpExchange exchange) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String topic = json.getOrDefault("topic", "Data Science");
        int count = Integer.parseInt(json.getOrDefault("numQuestions", "5"));
        String difficulty = json.getOrDefault("difficulty", "Medium");

        Quiz quiz = QuizGenerator.generateQuiz(topic, count, difficulty);
        if (quiz.getError() != null) {
            sendJson(exchange, 400, "{\"error\": " + jsonEscape(quiz.getError()) + "}");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"title\": ").append(jsonEscape(quiz.getTitle())).append(",\n");
        sb.append("  \"questions\": [");
        List<QuizQuestion> qList = quiz.getQuestions();
        for (int i = 0; i < qList.size(); i++) {
            QuizQuestion q = qList.get(i);
            if (i > 0) sb.append(", ");
            sb.append("{\n");
            sb.append("    \"question\": ").append(jsonEscape(q.getQuestion())).append(",\n");
            sb.append("    \"options\": {\n");
            sb.append("      \"A\": ").append(jsonEscape(q.getOptions().getOrDefault("A", ""))).append(",\n");
            sb.append("      \"B\": ").append(jsonEscape(q.getOptions().getOrDefault("B", ""))).append(",\n");
            sb.append("      \"C\": ").append(jsonEscape(q.getOptions().getOrDefault("C", ""))).append(",\n");
            sb.append("      \"D\": ").append(jsonEscape(q.getOptions().getOrDefault("D", ""))).append("\n");
            sb.append("    },\n");
            sb.append("    \"answer\": ").append(jsonEscape(q.getAnswer())).append(",\n");
            sb.append("    \"explanation\": ").append(jsonEscape(q.getExplanation())).append("\n");
            sb.append("  }");
        }
        sb.append("]\n");
        sb.append("}");

        sendJson(exchange, 200, sb.toString());
    }

    private void handleQuizSubmit(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String title = json.getOrDefault("title", "Practice Quiz");
        int correct = Integer.parseInt(json.getOrDefault("correctCount", "0"));
        int total = Integer.parseInt(json.getOrDefault("total", "5"));
        double pct = Double.parseDouble(json.getOrDefault("score", "0"));

        Database.logActivity(
            currentUser.getId(),
            "Quiz",
            "Quiz: " + title,
            "Score: " + correct + "/" + total,
            "Scored " + pct + "% on " + total + " questions.",
            pct
        );

        sendJson(exchange, 200, "{\"success\": true}");
    }

    private void handlePdfUpload(HttpExchange exchange) throws IOException {
        // Read body as raw bytes or parse base64
        byte[] bytes = readAllBytes(exchange.getRequestBody());
        String text;
        String filename = "uploaded_document.pdf";

        // Check if body is JSON with base64 data
        String bodyStr = new String(bytes, StandardCharsets.UTF_8);
        if (bodyStr.startsWith("{") && bodyStr.contains("\"base64\"")) {
            Map<String, String> json = parseSimpleJson(bodyStr);
            filename = json.getOrDefault("filename", "document.pdf");
            String b64 = json.getOrDefault("base64", "");
            if (b64.contains(",")) {
                b64 = b64.substring(b64.indexOf(',') + 1);
            }
            byte[] pdfData = Base64.getDecoder().decode(b64);
            text = PdfReaderService.extractTextFromPdf(pdfData);
        } else {
            text = PdfReaderService.extractTextFromPdf(bytes);
        }

        if (text.startsWith("ERROR:")) {
            sendJson(exchange, 400, "{\"error\": " + jsonEscape(text) + "}");
            return;
        }

        int wordCount = text.split("\\s+").length;
        sendJson(exchange, 200, """
            {
              "filename": %s,
              "text": %s,
              "wordCount": %d
            }
        """.formatted(jsonEscape(filename), jsonEscape(text), wordCount));
    }

    private void handlePdfAction(HttpExchange exchange, User currentUser) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String action = json.getOrDefault("action", "");
        String pdfText = json.getOrDefault("pdfText", "");
        String question = json.getOrDefault("question", "");
        String filename = json.getOrDefault("filename", "document.pdf");

        String answer;
        switch (action) {
            case "summary" -> answer = PdfReaderService.getExecutiveSummary(pdfText);
            case "definitions" -> answer = PdfReaderService.getKeyDefinitions(pdfText);
            case "questions" -> answer = PdfReaderService.getPracticeQuestions(pdfText);
            case "ask" -> answer = PdfReaderService.askQuestion(pdfText, question);
            default -> answer = "Unknown action.";
        }

        if (currentUser != null) {
            String title = "PDF: " + filename + " (" + action + ")";
            Database.logActivity(
                currentUser.getId(),
                "PDF Study",
                title,
                question.isBlank() ? action : question,
                answer.length() > 300 ? answer.substring(0, 300) : answer,
                null
            );
        }

        sendJson(exchange, 200, "{\"answer\": " + jsonEscape(answer) + "}");
    }

    private void handleExamGenerate(HttpExchange exchange, User currentUser) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String examName = json.getOrDefault("examName", "");
        String examDays = json.getOrDefault("examDays", "7 Days (Standard Crash Course)");
        String examType = json.getOrDefault("examType", "Semester University Exam (Theory + Coding)");
        String topics = json.getOrDefault("challengingTopics", "All core topics");

        String guide = ExamGuideService.generateExamGuide(examName, examDays, examType, topics);

        if (currentUser != null && !examName.isBlank()) {
            Database.logActivity(
                currentUser.getId(),
                "Exam Guide",
                "Exam Guide: " + examName,
                examName + " (" + examDays + ")",
                guide.length() > 400 ? guide.substring(0, 400) : guide,
                null
            );
        }

        sendJson(exchange, 200, "{\"guide\": " + jsonEscape(guide) + "}");
    }

    // --- LINKEDIN HANDLERS ---
    private void handleLinkedInScore(HttpExchange exchange) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String headline = json.getOrDefault("headline", "");
        String summary = json.getOrDefault("summary", "");
        String skills = json.getOrDefault("skills", "");
        String experience = json.getOrDefault("experience", "");
        String profileUrl = json.getOrDefault("profileUrl", "");

        LinkedInTracker.ScoreResult res = LinkedInTracker.calculateScore(headline, summary, skills, experience, profileUrl);
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"score\": ").append(res.score).append(",\n");
        sb.append("  \"feedbackItems\": [");
        for (int i = 0; i < res.feedbackItems.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(jsonEscape(res.feedbackItems.get(i)));
        }
        sb.append("]\n");
        sb.append("}");

        sendJson(exchange, 200, sb.toString());
    }

    private void handleLinkedInAudit(HttpExchange exchange, User currentUser) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String headline = json.getOrDefault("headline", "");
        String summary = json.getOrDefault("summary", "");
        String skills = json.getOrDefault("skills", "");
        String targetRole = json.getOrDefault("targetRole", "Data Science & AI Intern");
        String interest = json.getOrDefault("interest", "Data Science & AI");
        String profileUrl = json.getOrDefault("profileUrl", "");

        String auditRaw = LinkedInTracker.analyzeProfileAi(headline, summary, skills, targetRole, interest);

        if (currentUser != null) {
            Database.updateUserProfile(
                currentUser.getId(),
                currentUser.getFullName(),
                currentUser.getCollege(),
                currentUser.getBranch(),
                interest,
                profileUrl,
                targetRole,
                skills
            );
            Database.logActivity(
                currentUser.getId(),
                "Career",
                "LinkedIn Profile Audit",
                targetRole,
                "Audit generated for " + targetRole,
                null
            );
        }

        sendJson(exchange, 200, "{\"audit\": " + jsonEscape(auditRaw) + "}");
    }

    // --- INTERNSHIPS HANDLERS ---
    private void handleGetInternships(HttpExchange exchange) throws IOException {
        String query = exchange.getRequestURI().getQuery();
        Map<String, String> params = parseQueryParams(query);

        String category = params.getOrDefault("category", "All Interests");
        String mode = params.getOrDefault("mode", "All Modes");
        String q = params.getOrDefault("q", "");

        List<Internship> list = InternshipService.getInternships(category, mode, q);
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            Internship in = list.get(i);
            if (i > 0) sb.append(", ");
            sb.append("{\n");
            sb.append("  \"id\": ").append(jsonEscape(in.getId())).append(",\n");
            sb.append("  \"title\": ").append(jsonEscape(in.getTitle())).append(",\n");
            sb.append("  \"company\": ").append(jsonEscape(in.getCompany())).append(",\n");
            sb.append("  \"emoji\": ").append(jsonEscape(in.getEmoji())).append(",\n");
            sb.append("  \"category\": ").append(jsonEscape(in.getCategory())).append(",\n");
            sb.append("  \"location\": ").append(jsonEscape(in.getLocation())).append(",\n");
            sb.append("  \"stipend\": ").append(jsonEscape(in.getStipend())).append(",\n");
            sb.append("  \"duration\": ").append(jsonEscape(in.getDuration())).append(",\n");
            sb.append("  \"mode\": ").append(jsonEscape(in.getMode())).append(",\n");
            sb.append("  \"description\": ").append(jsonEscape(in.getDescription())).append(",\n");
            sb.append("  \"applyUrl\": ").append(jsonEscape(in.getApplyUrl())).append(",\n");
            sb.append("  \"skills\": [");
            for (int k = 0; k < in.getSkills().size(); k++) {
                if (k > 0) sb.append(", ");
                sb.append(jsonEscape(in.getSkills().get(k)));
            }
            sb.append("]\n");
            sb.append("}");
        }
        sb.append("]");

        sendJson(exchange, 200, sb.toString());
    }

    private void handleInternshipPitch(HttpExchange exchange, User currentUser) throws IOException {
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        String internshipId = json.getOrDefault("internshipId", "");

        List<Internship> all = InternshipService.getInternships("All Interests", "All Modes", "");
        Internship selected = null;
        for (Internship in : all) {
            if (in.getId().equals(internshipId)) {
                selected = in;
                break;
            }
        }

        if (selected == null) {
            sendJson(exchange, 404, "{\"error\": \"Internship not found\"}");
            return;
        }

        String pitch = InternshipService.generateInternshipPitch(selected, currentUser);
        sendJson(exchange, 200, "{\"pitch\": " + jsonEscape(pitch) + "}");
    }

    private void handleGetTrackedInternships(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        List<Internship> tracked = Database.getUserInternships(currentUser.getId());
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < tracked.size(); i++) {
            Internship in = tracked.get(i);
            if (i > 0) sb.append(", ");
            sb.append("{\n");
            sb.append("  \"id\": ").append(in.getDbId()).append(",\n");
            sb.append("  \"company\": ").append(jsonEscape(in.getCompany())).append(",\n");
            sb.append("  \"role\": ").append(jsonEscape(in.getTitle())).append(",\n");
            sb.append("  \"location\": ").append(jsonEscape(in.getLocation())).append(",\n");
            sb.append("  \"stipend\": ").append(jsonEscape(in.getStipend())).append(",\n");
            sb.append("  \"status\": ").append(jsonEscape(in.getStatus())).append(",\n");
            sb.append("  \"notes\": ").append(jsonEscape(in.getNotes())).append(",\n");
            sb.append("  \"appliedAt\": ").append(jsonEscape(in.getAppliedAt())).append("\n");
            sb.append("}");
        }
        sb.append("]");

        sendJson(exchange, 200, sb.toString());
    }

    private void handleTrackInternship(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);

        boolean ok = Database.saveUserInternship(
            currentUser.getId(),
            json.getOrDefault("company", ""),
            json.getOrDefault("role", ""),
            json.getOrDefault("location", "Remote"),
            json.getOrDefault("stipend", "Stipend Provided"),
            json.getOrDefault("status", "Interested"),
            json.getOrDefault("notes", "")
        );

        sendJson(exchange, 200, "{\"success\": " + ok + "}");
    }

    private void handleDeleteInternship(HttpExchange exchange, User currentUser) throws IOException {
        if (currentUser == null) {
            sendJson(exchange, 401, "{\"error\": \"Unauthenticated\"}");
            return;
        }
        String body = readBody(exchange);
        Map<String, String> json = parseSimpleJson(body);
        int id = Integer.parseInt(json.getOrDefault("id", "0"));

        Database.deleteUserInternship(id, currentUser.getId());
        sendJson(exchange, 200, "{\"success\": true}");
    }

    // --- JSON & UTILITY HELPERS ---
    public static void sendJson(HttpExchange exchange, int statusCode, String jsonResponse) throws IOException {
        byte[] bytes = jsonResponse.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String readBody(HttpExchange exchange) throws IOException {
        return new String(readAllBytes(exchange.getRequestBody()), StandardCharsets.UTF_8);
    }

    private byte[] readAllBytes(InputStream is) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[8192];
        int nRead;
        while ((nRead = is.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, nRead);
        }
        return buffer.toByteArray();
    }

    private Map<String, String> parseSimpleJson(String json) {
        Map<String, String> map = new HashMap<>();
        if (json == null || json.isBlank()) return map;

        // Match "key": "value" or "key": 123 or "key": true
        Pattern pattern = Pattern.compile("\"([^\"]+)\"\\s*:\\s*(?:\"([^\"]*)\"|([0-9.]+|true|false|null))");
        Matcher matcher = pattern.matcher(json);
        while (matcher.find()) {
            String key = matcher.group(1);
            String strVal = matcher.group(2);
            String primVal = matcher.group(3);
            if (strVal != null) {
                map.put(key, unescape(strVal));
            } else if (primVal != null) {
                map.put(key, primVal);
            }
        }
        return map;
    }

    private Map<String, String> parseQueryParams(String query) {
        Map<String, String> params = new HashMap<>();
        if (query == null || query.isBlank()) return params;
        for (String pair : query.split("&")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2) {
                params.put(urlDecode(kv[0]), urlDecode(kv[1]));
            }
        }
        return params;
    }

    private String urlDecode(String s) {
        try {
            return java.net.URLDecoder.decode(s, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return s;
        }
    }

    private String userToJson(User u) {
        if (u == null) return "null";
        return """
            {
              "id": %d,
              "username": %s,
              "email": %s,
              "fullName": %s,
              "college": %s,
              "branch": %s,
              "interests": %s,
              "linkedinUrl": %s,
              "targetRole": %s,
              "skills": %s,
              "createdAt": %s
            }
        """.formatted(
            u.getId(),
            jsonEscape(u.getUsername()),
            jsonEscape(u.getEmail()),
            jsonEscape(u.getFullName()),
            jsonEscape(u.getCollege()),
            jsonEscape(u.getBranch()),
            jsonEscape(u.getInterests()),
            jsonEscape(u.getLinkedinUrl()),
            jsonEscape(u.getTargetRole()),
            jsonEscape(u.getSkills()),
            jsonEscape(u.getCreatedAt())
        );
    }

    private String jsonEscape(String s) {
        return GeminiClient.jsonEscape(s);
    }

    private String unescape(String s) {
        return s.replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\t", "\t");
    }
}
