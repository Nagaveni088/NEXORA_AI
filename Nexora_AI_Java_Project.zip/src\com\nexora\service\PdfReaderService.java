package com.nexora.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.*;

public class PdfReaderService {

    public static String extractTextFromPdf(byte[] pdfBytes) {
        if (pdfBytes == null || pdfBytes.length == 0) {
            return "";
        }

        try (InputStream in = new ByteArrayInputStream(pdfBytes);
             PDDocument document = PDDocument.load(in)) {

            if (document.isEncrypted()) {
                return "ERROR: This PDF is password-protected.";
            }

            PDFTextStripper stripper = new PDFTextStripper();
            String fullText = stripper.getText(document);

            if (fullText == null || fullText.trim().isEmpty()) {
                return "ERROR: No readable text was found in this PDF. It may contain scanned images. Use OCR to extract text.";
            }

            return fullText.trim();

        } catch (Exception e) {
            System.err.println("PDF extraction error: " + e.getMessage());
            return "ERROR: Unable to read this PDF. Please upload a valid PDF document.";
        }
    }

    public static String selectRelevantPassages(String text, String question, int maxChars) {
        if (text == null || text.isBlank()) return "";
        if (question == null || question.isBlank() || text.length() <= maxChars) {
            return text.substring(0, Math.min(text.length(), maxChars));
        }

        Set<String> questionWords = new HashSet<>();
        for (String w : question.toLowerCase().split("\\s+")) {
            String clean = w.replaceAll("[^a-zA-Z0-9]", "");
            if (clean.length() > 2) {
                questionWords.add(clean);
            }
        }

        String[] paragraphs = text.split("\n\n+");
        if (paragraphs.length <= 1) {
            paragraphs = text.split("\n");
        }

        class ScoredPassage {
            final int index;
            final double score;
            final String text;

            ScoredPassage(int index, double score, String text) {
                this.index = index;
                this.score = score;
                this.text = text;
            }
        }

        List<ScoredPassage> scored = new ArrayList<>();
        for (int i = 0; i < paragraphs.length; i++) {
            String p = paragraphs[i].trim();
            if (p.isEmpty()) continue;

            double score = 0;
            for (String w : p.toLowerCase().split("\\s+")) {
                String clean = w.replaceAll("[^a-zA-Z0-9]", "");
                if (questionWords.contains(clean)) {
                    score += 1.0;
                }
            }
            if (p.startsWith("--- Page")) {
                score -= 0.1;
            }
            scored.add(new ScoredPassage(i, score, p));
        }

        scored.sort((a, b) -> {
            int cmp = Double.compare(b.score, a.score);
            if (cmp != 0) return cmp;
            return Integer.compare(a.index, b.index);
        });

        List<ScoredPassage> selected = new ArrayList<>();
        int totalChars = 0;
        for (ScoredPassage sp : scored) {
            if (totalChars + sp.text.length() + 2 > maxChars) {
                continue;
            }
            selected.add(sp);
            totalChars += sp.text.length() + 2;
        }

        selected.sort(Comparator.comparingInt(a -> a.index));
        StringBuilder result = new StringBuilder();
        for (ScoredPassage sp : selected) {
            if (!result.isEmpty()) result.append("\n\n");
            result.append(sp.text);
        }

        return result.toString();
    }

    public static String getExecutiveSummary(String pdfText) {
        String truncated = pdfText.substring(0, Math.min(pdfText.length(), 14000));
        String prompt = "Provide a comprehensive, student-friendly executive summary of this document:\n\n" + truncated;
        return GeminiClient.getAiResponse(prompt, "You are an expert academic summarizer.");
    }

    public static String getKeyDefinitions(String pdfText) {
        String truncated = pdfText.substring(0, Math.min(pdfText.length(), 14000));
        String prompt = "Extract all important definitions, technical terms, and formulas from this document with concise explanations:\n\n" + truncated;
        return GeminiClient.getAiResponse(prompt, "You are an expert engineering instructor.");
    }

    public static String getPracticeQuestions(String pdfText) {
        String truncated = pdfText.substring(0, Math.min(pdfText.length(), 14000));
        String prompt = "Create 5 high-yield exam practice questions based on this text, along with detailed model answers:\n\n" + truncated;
        return GeminiClient.getAiResponse(prompt, "You are an academic exam creator.");
    }

    public static String askQuestion(String pdfText, String question) {
        String context = selectRelevantPassages(pdfText, question, 12000);
        String prompt = "Context from student's PDF document:\n" + context +
            "\n\nStudent Question: " + question +
            "\n\nAnswer accurately based only on the context provided.";
        return GeminiClient.getAiResponse(
            prompt,
            "You are an expert teaching assistant answering questions strictly grounded in the student's uploaded material."
        );
    }
}
