package com.nexora.service;

import com.nexora.model.Quiz;
import com.nexora.model.QuizQuestion;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QuizGenerator {

    public static Quiz generateQuiz(String topic, int numQuestions, String difficulty) {
        if (topic == null || topic.trim().isEmpty()) {
            return new Quiz("Please enter a topic.");
        }

        numQuestions = Math.max(1, Math.min(numQuestions, 20));
        if (difficulty == null || difficulty.isBlank()) difficulty = "Medium";

        String prompt = """
Create a multiple-choice educational quiz.

Topic: %s
Number of questions: %d
Difficulty: %s

Return ONLY valid JSON in this exact format:

{
  "title": "Quiz title",
  "questions": [
    {
      "question": "Question text",
      "options": {
        "A": "First option",
        "B": "Second option",
        "C": "Third option",
        "D": "Fourth option"
      },
      "answer": "A",
      "explanation": "Explain why the answer is correct."
    }
  ]
}

Requirements:
- Generate exactly %d questions.
- Include four options per question.
- There must be exactly one correct answer per question.
- The answer must be A, B, C, or D.
- Ensure the questions and answers are factually accurate.
- Do not repeat questions.
- Match the requested difficulty.
- Do not include Markdown or text outside the JSON.
""".formatted(topic, numQuestions, difficulty, numQuestions);

        String response = GeminiClient.getAiResponse(
            prompt,
            "You are NEXORA AI, an educational quiz generator. Create accurate questions and return valid JSON only."
        );

        if (response == null || response.isBlank()) {
            return new Quiz("The AI returned an empty response.");
        }

        try {
            return parseQuizJson(response);
        } catch (Exception e) {
            System.err.println("Quiz parsing error: " + e.getMessage());
            return new Quiz("Unable to create the quiz in the expected format. Please try again.");
        }
    }

    public static Quiz parseQuizJson(String response) {
        String cleaned = response.trim();
        // Remove markdown ```json ... ```
        if (cleaned.startsWith("```")) {
            int endFence = cleaned.indexOf('\n');
            if (endFence != -1) {
                cleaned = cleaned.substring(endFence + 1);
            }
            if (cleaned.endsWith("```")) {
                cleaned = cleaned.substring(0, cleaned.length() - 3);
            }
        }
        cleaned = cleaned.trim();

        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        if (start == -1 || end == -1 || end <= start) {
            return new Quiz("No valid JSON structure found in AI response.");
        }
        String json = cleaned.substring(start, end + 1);

        String title = extractJsonField(json, "title");
        if (title.isEmpty()) title = "NEXORA AI Practice Quiz";

        List<QuizQuestion> questions = new ArrayList<>();

        // Locate "questions": [ ... ]
        int qArrStart = json.indexOf("\"questions\"");
        if (qArrStart != -1) {
            int bracketStart = json.indexOf('[', qArrStart);
            int bracketEnd = findMatchingBracket(json, bracketStart, '[', ']');
            if (bracketStart != -1 && bracketEnd != -1) {
                String arrayContent = json.substring(bracketStart + 1, bracketEnd);
                List<String> questionObjects = splitJsonObjects(arrayContent);

                for (String qObj : questionObjects) {
                    String qText = extractJsonField(qObj, "question");
                    String ans = extractJsonField(qObj, "answer").toUpperCase().trim();
                    String explanation = extractJsonField(qObj, "explanation");

                    Map<String, String> options = new LinkedHashMap<>();
                    int optIdx = qObj.indexOf("\"options\"");
                    if (optIdx != -1) {
                        int optBraceStart = qObj.indexOf('{', optIdx);
                        int optBraceEnd = findMatchingBracket(qObj, optBraceStart, '{', '}');
                        if (optBraceStart != -1 && optBraceEnd != -1) {
                            String optJson = qObj.substring(optBraceStart + 1, optBraceEnd);
                            options.put("A", extractJsonField(optJson, "A"));
                            options.put("B", extractJsonField(optJson, "B"));
                            options.put("C", extractJsonField(optJson, "C"));
                            options.put("D", extractJsonField(optJson, "D"));
                        }
                    }

                    if (!qText.isBlank() && options.size() == 4 && !options.get("A").isBlank() &&
                        (ans.equals("A") || ans.equals("B") || ans.equals("C") || ans.equals("D"))) {
                        questions.add(new QuizQuestion(qText, options, ans, explanation));
                    }
                }
            }
        }

        if (questions.isEmpty()) {
            return new Quiz("No valid multiple-choice questions found.");
        }

        return new Quiz(title, questions);
    }

    private static String extractJsonField(String json, String field) {
        Pattern pattern = Pattern.compile("\"" + Pattern.quote(field) + "\"\\s*:\\s*\"([^\"]*)\"");
        Matcher matcher = pattern.matcher(json);
        if (matcher.find()) {
            return unescapeJson(matcher.group(1));
        }
        return "";
    }

    private static int findMatchingBracket(String text, int startPos, char openChar, char closeChar) {
        if (startPos < 0 || startPos >= text.length()) return -1;
        int depth = 0;
        boolean inQuotes = false;
        boolean escaped = false;

        for (int i = startPos; i < text.length(); i++) {
            char c = text.charAt(i);
            if (escaped) {
                escaped = false;
                continue;
            }
            if (c == '\\') {
                escaped = true;
                continue;
            }
            if (c == '"') {
                inQuotes = !inQuotes;
                continue;
            }
            if (!inQuotes) {
                if (c == openChar) depth++;
                else if (c == closeChar) {
                    depth--;
                    if (depth == 0) return i;
                }
            }
        }
        return -1;
    }

    private static List<String> splitJsonObjects(String arrayContent) {
        List<String> list = new ArrayList<>();
        int i = 0;
        while (i < arrayContent.length()) {
            int objStart = arrayContent.indexOf('{', i);
            if (objStart == -1) break;
            int objEnd = findMatchingBracket(arrayContent, objStart, '{', '}');
            if (objEnd == -1) break;
            list.add(arrayContent.substring(objStart, objEnd + 1));
            i = objEnd + 1;
        }
        return list;
    }

    private static String unescapeJson(String s) {
        return s.replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\t", "\t");
    }
}
