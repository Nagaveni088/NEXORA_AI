package com.nexora.service;

import com.nexora.model.Internship;
import com.nexora.model.User;

import java.util.ArrayList;
import java.util.List;

public class InternshipService {
    private static final List<Internship> INTERNSHIP_DATABASE = new ArrayList<>();

    static {
        // Data Science & AI
        INTERNSHIP_DATABASE.add(new Internship(
            "ds_01", "Data Science & Analytics Intern", "Swiggy Data Labs", "🍔",
            "Data Science & AI", "Remote / Bengaluru", "₹28,000 / month", "6 Months", "Remote",
            List.of("Python", "Pandas", "SQL", "Data Visualization", "Machine Learning"),
            "Work with Swiggy's analytics team analyzing millions of orders, predicting demand patterns, and building automated dashboards.",
            "https://careers.swiggy.com"
        ));

        INTERNSHIP_DATABASE.add(new Internship(
            "ds_02", "Machine Learning Research Intern", "TensorWorks AI", "🧠",
            "Data Science & AI", "Hyderabad / Remote", "₹35,000 / month", "3 - 6 Months", "Remote",
            List.of("PyTorch", "NLP", "Transformers", "Python", "FastAPI"),
            "Fine-tune open-source LLMs, experiment with RAG pipelines, and build evaluation benchmarks for enterprise AI models.",
            "https://careers.google.com/students"
        ));

        INTERNSHIP_DATABASE.add(new Internship(
            "ds_03", "Business Intelligence & Data Analyst Intern", "Zomato Intelligence", "📊",
            "Data Science & AI", "Gurugram / Hybrid", "₹25,000 / month", "3 Months", "Hybrid",
            List.of("SQL", "PowerBI / Tableau", "Python", "Excel", "Statistics"),
            "Derive actionable business insights from customer retention cohorts and optimize restaurant partner economics.",
            "https://www.zomato.com/careers"
        ));

        INTERNSHIP_DATABASE.add(new Internship(
            "ds_04", "Computer Vision & Deep Learning Intern", "AeroVision Robotics", "🛰️",
            "Data Science & AI", "Pune / Remote", "₹30,000 / month", "6 Months", "Remote",
            List.of("OpenCV", "PyTorch", "YOLO", "Python", "Image Processing"),
            "Develop edge-deployed object detection and anomaly recognition models for autonomous drone inspection.",
            "https://internshala.com"
        ));

        // Full Stack & Web Development
        INTERNSHIP_DATABASE.add(new Internship(
            "web_01", "Full Stack Web Developer Intern", "Razorpay Payments", "💳",
            "Full Stack & Web Development", "Bengaluru / Hybrid", "₹35,000 / month", "6 Months", "Hybrid",
            List.of("React.js", "Node.js", "TypeScript", "PostgreSQL", "REST APIs"),
            "Build responsive merchant dashboards and payment checkout widgets used by millions of online shoppers daily.",
            "https://razorpay.com/jobs"
        ));

        INTERNSHIP_DATABASE.add(new Internship(
            "web_02", "Frontend React / Next.js Intern", "Cred Experience Labs", "💎",
            "Full Stack & Web Development", "Remote", "₹30,000 / month", "4 Months", "Remote",
            List.of("Next.js", "React", "Tailwind CSS", "JavaScript", "Framer Motion"),
            "Craft pixel-perfect, accessible, and high-performance user interfaces with smooth micro-interactions.",
            "https://cred.club/careers"
        ));

        INTERNSHIP_DATABASE.add(new Internship(
            "web_03", "Backend Java / Spring Boot Intern", "Postman Platform", "🚀",
            "Full Stack & Web Development", "Remote", "₹40,000 / month", "6 Months", "Remote",
            List.of("Java", "Spring Boot", "REST APIs", "Microservices", "Docker"),
            "Design highly scalable microservices, API documentation tooling, and developer ecosystem integrations.",
            "https://www.postman.com/company/careers"
        ));

        // Cloud Computing & DevOps
        INTERNSHIP_DATABASE.add(new Internship(
            "cloud_01", "Cloud Engineering & DevOps Intern", "CloudScale Networks", "☁️",
            "Cloud Computing & DevOps", "Bengaluru / Remote", "₹32,000 / month", "6 Months", "Remote",
            List.of("AWS", "Docker", "Kubernetes", "Linux", "Terraform"),
            "Maintain containerized Kubernetes clusters, automate CI/CD release pipelines, and optimize AWS cloud costs.",
            "https://aws.amazon.com/careers"
        ));

        // Cybersecurity & Network Defense
        INTERNSHIP_DATABASE.add(new Internship(
            "sec_01", "Cybersecurity Analyst Intern", "Fortify Guard Labs", "🛡️",
            "Cybersecurity & Network Defense", "Remote", "₹26,000 / month", "4 Months", "Remote",
            List.of("Network Security", "Wireshark", "Linux", "Penetration Testing", "Python"),
            "Monitor security telemetry, simulate vulnerability testing, and write proactive threat response playbooks.",
            "https://careers.paloaltonetworks.com"
        ));

        // Mobile App Development
        INTERNSHIP_DATABASE.add(new Internship(
            "mob_01", "Android / Flutter App Intern", "Zerodha Mobile", "📱",
            "Mobile App Development", "Bengaluru / Remote", "₹35,000 / month", "6 Months", "Remote",
            List.of("Flutter", "Dart", "Android", "State Management", "REST APIs"),
            "Optimize latency-critical financial trading mobile interfaces and build lightweight offline caching engines.",
            "https://zerodha.com/careers"
        ));

        // Product Management & Analytics
        INTERNSHIP_DATABASE.add(new Internship(
            "pm_01", "Associate Product Manager Intern", "Groww Fintech", "📈",
            "Product Management & Analytics", "Bengaluru / Hybrid", "₹30,000 / month", "3 Months", "Hybrid",
            List.of("Product Strategy", "User Research", "Wireframing", "SQL", "A/B Testing"),
            "Work alongside Senior PMs conducting student user interviews, creating feature PRDs, and running experiments.",
            "https://groww.in/careers"
        ));
    }

    public static List<Internship> getInternships(String category, String mode, String query) {
        List<Internship> results = new ArrayList<>();

        for (Internship in : INTERNSHIP_DATABASE) {
            boolean matchCat = true;
            if (category != null && !category.isBlank() && !category.equalsIgnoreCase("All Interests")) {
                String catLower = category.toLowerCase();
                String inCatLower = in.getCategory().toLowerCase();
                boolean skillMatch = false;
                for (String s : in.getSkills()) {
                    if (catLower.contains(s.toLowerCase())) {
                        skillMatch = true;
                        break;
                    }
                }
                matchCat = inCatLower.contains(catLower) || skillMatch || inCatLower.contains(catLower.split("&")[0].trim());
            }

            boolean matchMode = true;
            if (mode != null && !mode.isBlank() && !mode.equalsIgnoreCase("All Modes")) {
                matchMode = in.getMode().equalsIgnoreCase(mode);
            }

            boolean matchQ = true;
            if (query != null && !query.isBlank()) {
                String q = query.trim().toLowerCase();
                boolean qSkillMatch = false;
                for (String s : in.getSkills()) {
                    if (s.toLowerCase().contains(q)) {
                        qSkillMatch = true;
                        break;
                    }
                }
                matchQ = in.getTitle().toLowerCase().contains(q) ||
                         in.getCompany().toLowerCase().contains(q) ||
                         in.getDescription().toLowerCase().contains(q) ||
                         qSkillMatch;
            }

            if (matchCat && matchMode && matchQ) {
                results.add(in);
            }
        }

        return results;
    }

    public static String generateInternshipPitch(Internship internship, User user) {
        String name = user != null && user.getFullName() != null && !user.getFullName().isBlank()
            ? user.getFullName()
            : (user != null && user.getUsername() != null ? user.getUsername() : "Student");
        String college = user != null && user.getCollege() != null && !user.getCollege().isBlank()
            ? user.getCollege() : "University";
        String branch = user != null && user.getBranch() != null && !user.getBranch().isBlank()
            ? user.getBranch() : "Computer Science";
        String skills = user != null && user.getSkills() != null && !user.getSkills().isBlank()
            ? user.getSkills() : "Java, Python, Problem Solving, Git";
        String targetRole = user != null && user.getTargetRole() != null && !user.getTargetRole().isBlank()
            ? user.getTargetRole() : internship.getTitle();

        String prompt = """
Write a high-converting, professional, yet personable internship application pitch / cold email
from a student directly to a hiring manager or tech lead.

Applicant Details:
- Name: %s
- Education: %s at %s
- Core Skills: %s
- Aspirations: %s

Internship Details:
- Role: %s
- Company: %s
- Key Requirements: %s
- Overview: %s

Guidelines:
- Subject Line: Compelling and concise.
- Opening: Hook the reader by mentioning something specific about %s.
- Body: Connect applicant's skills and projects to what the team is building.
- Call to action: Polite invitation for a 10-minute introductory chat or review of GitHub/portfolio.
- Tone: Confident, humble, enthusiastic, professional.
- Length: Around 180-220 words. No robotic fluff.
""".formatted(
            name, branch, college, skills, targetRole,
            internship.getTitle(), internship.getCompany(), String.join(", ", internship.getSkills()),
            internship.getDescription(), internship.getCompany()
        );

        return GeminiClient.getAiResponse(
            prompt,
            "You are an expert career advisor crafting winning internship application pitches for top students."
        );
    }
}
