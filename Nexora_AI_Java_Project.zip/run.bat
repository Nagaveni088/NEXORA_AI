@echo off
echo ===================================================
echo  Starting NEXORA AI Student App (Java Edition)
echo ===================================================

if not exist "bin\com\nexora\Main.class" (
    echo Building project first...
    call build.bat
)

echo Launching Java Application on http://localhost:8501 ...
java -cp "bin;lib/*" com.nexora.Main
pause
