package com.nexora.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Config {
    private static final Map<String, String> ENV = new HashMap<>();
    public static final String[] MODEL_CANDIDATES = {
        "gemini-3.5-flash",
        "gemini-3.1-flash-lite",
        "gemini-3.8-flash",
        "gemini-flash-latest"
    };

    static {
        loadEnv();
    }

    private static void loadEnv() {
        File envFile = new File(".env");
        if (envFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(envFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    int idx = line.indexOf('=');
                    if (idx > 0) {
                        String key = line.substring(0, idx).trim();
                        String val = line.substring(idx + 1).trim();
                        if (val.startsWith("\"") && val.endsWith("\"") && val.length() >= 2) {
                            val = val.substring(1, val.length() - 1);
                        } else if (val.startsWith("'") && val.endsWith("'") && val.length() >= 2) {
                            val = val.substring(1, val.length() - 1);
                        }
                        ENV.put(key, val);
                    }
                }
            } catch (IOException e) {
                System.err.println("Warning: Could not read .env file: " + e.getMessage());
            }
        }
    }

    public static String get(String key, String defaultValue) {
        String val = System.getenv(key);
        if (val != null && !val.isBlank()) return val;
        val = ENV.get(key);
        if (val != null && !val.isBlank()) return val;
        return defaultValue;
    }

    public static String getGeminiApiKey() {
        return get("GEMINI_API_KEY", "");
    }

    public static int getPort() {
        try {
            return Integer.parseInt(get("PORT", "8501"));
        } catch (NumberFormatException e) {
            return 8501;
        }
    }
}
