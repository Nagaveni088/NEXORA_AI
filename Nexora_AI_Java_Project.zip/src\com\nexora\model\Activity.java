package com.nexora.model;

public class Activity {
    private int id;
    private int userId;
    private String activityType;
    private String title;
    private String inputText;
    private String outputText;
    private Double score;
    private String createdAt;

    public Activity() {}

    public Activity(int id, int userId, String activityType, String title,
                    String inputText, String outputText, Double score, String createdAt) {
        this.id = id;
        this.userId = userId;
        this.activityType = activityType;
        this.title = title;
        this.inputText = inputText;
        this.outputText = outputText;
        this.score = score;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getActivityType() { return activityType; }
    public void setActivityType(String activityType) { this.activityType = activityType; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getInputText() { return inputText; }
    public void setInputText(String inputText) { this.inputText = inputText; }

    public String getOutputText() { return outputText; }
    public void setOutputText(String outputText) { this.outputText = outputText; }

    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
