// ==============================================================================
// NEXORA AI STUDENT APP - CLIENT LOGIC (Java Backend Integration)
// ==============================================================================

const state = {
  user: null,
  token: localStorage.getItem("session_token") || "",
  currentPage: "dashboard",
  activeQuiz: null,
  activePdf: null,
  pdfHistory: []
};

// --- INITIALIZATION ---
document.addEventListener("DOMContentLoaded", () => {
  setupNavigation();
  setupSubTabs();
  setupForms();
  checkAuth();
});

// --- API HELPER ---
async function api(endpoint, method = "GET", body = null) {
  const headers = { "Content-Type": "application/json" };
  if (state.token) {
    headers["Authorization"] = `Bearer ${state.token}`;
  }

  const options = { method, headers };
  if (body) {
    options.body = JSON.stringify(body);
  }

  try {
    const res = await fetch(endpoint, options);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || data.message || `Request failed (${res.status})`);
    }
    return data;
  } catch (err) {
    showAlert(err.message, "error");
    throw err;
  }
}

function showAlert(message, type = "info") {
  const el = document.getElementById("global-alert");
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.textContent = message;
  el.style.display = "block";
  setTimeout(() => { el.style.display = "none"; }, 4000);
}

// --- AUTHENTICATION ---
async function checkAuth() {
  if (!state.token) {
    showPage("auth");
    return;
  }

  try {
    const user = await api("/api/user/me");
    if (user && user.id) {
      state.user = user;
      updateUserGreeting();
      showPage(state.currentPage || "dashboard");
      loadDashboard();
    } else {
      logout();
    }
  } catch (e) {
    logout();
  }
}

function updateUserGreeting() {
  const greetingEl = document.getElementById("header-user-greeting");
  if (!greetingEl) return;
  if (state.user) {
    const name = state.user.fullName || state.user.username || "Student";
    greetingEl.textContent = `Hi, ${name.slice(0, 12)}`;
    document.getElementById("main-nav").style.display = "flex";
  } else {
    greetingEl.textContent = "Hi, Student";
    document.getElementById("main-nav").style.display = "none";
  }
}

function logout() {
  state.token = "";
  state.user = null;
  localStorage.removeItem("session_token");
  api("/api/auth/logout", "POST").catch(() => {});
  updateUserGreeting();
  showPage("auth");
}

// --- NAVIGATION ---
function setupNavigation() {
  document.querySelectorAll(".mobile-nav-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const page = btn.dataset.page;
      showPage(page);
    });
  });
}

function showPage(pageId) {
  state.currentPage = pageId;

  // Toggle pages
  document.querySelectorAll(".page-section").forEach(p => p.style.display = "none");
  const target = document.getElementById(`${pageId}-page`);
  if (target) target.style.display = "block";

  // Toggle nav buttons
  document.querySelectorAll(".mobile-nav-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.page === pageId);
  });

  if (pageId === "dashboard") loadDashboard();
  if (pageId === "internships") loadInternships();
  if (pageId === "profile") loadProfile();
  if (pageId === "linkedin") updateLinkedInScoreMeter();
}

function navigateTo(pageId, subTabId = null) {
  showPage(pageId);
  if (subTabId) {
    const subBtn = document.querySelector(`[data-sub="${subTabId}"]`);
    if (subBtn) subBtn.click();
  }
}

// --- SUB TABS ---
function setupSubTabs() {
  document.querySelectorAll(".sub-tab-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const parent = btn.closest(".sub-tabs");
      parent.querySelectorAll(".sub-tab-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      // Auth tabs
      if (btn.dataset.tab) {
        document.querySelectorAll("#auth-page .tab-content").forEach(tc => tc.style.display = "none");
        const t = document.getElementById(`${btn.dataset.tab}-tab`);
        if (t) t.style.display = "block";
      }

      // Submode tabs
      if (btn.dataset.sub) {
        const page = btn.closest(".page-section");
        page.querySelectorAll(".submode-content").forEach(sc => sc.style.display = "none");
        const sm = document.getElementById(`sub-${btn.dataset.sub}`);
        if (sm) sm.style.display = "block";
      }
    });
  });
}

// --- EXPANDER TOGGLE ---
function toggleExpander(headerEl) {
  const body = headerEl.nextElementSibling;
  const arrow = headerEl.querySelector("span:last-child");
  if (body.style.display === "none") {
    body.style.display = "block";
    if (arrow) arrow.textContent = "▼";
  } else {
    body.style.display = "none";
    if (arrow) arrow.textContent = "▶";
  }
}

// --- FORMS SETUP ---
function setupForms() {
  // Register Form
  document.getElementById("form-register").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector("button[type=submit]");
    btn.innerHTML = `<span class="spinner"></span> Creating account...`;
    btn.disabled = true;

    try {
      const payload = {
        fullName: document.getElementById("reg-name").value.trim(),
        username: document.getElementById("reg-username").value.trim(),
        email: document.getElementById("reg-email").value.trim(),
        password: document.getElementById("reg-password").value,
        college: document.getElementById("reg-college").value.trim(),
        branch: document.getElementById("reg-branch").value.trim(),
        interests: document.getElementById("reg-interests").value
      };

      const res = await api("/api/auth/register", "POST", payload);
      if (res.success && res.token) {
        state.token = res.token;
        state.user = res.user;
        localStorage.setItem("session_token", res.token);
        updateUserGreeting();
        showAlert(res.message, "success");
        showPage("dashboard");
      }
    } catch (err) {
      // Alert handled in api()
    } finally {
      btn.innerHTML = `🚀 Create Free Account & Start Learning`;
      btn.disabled = false;
    }
  });

  // Login Form
  document.getElementById("form-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector("button[type=submit]");
    btn.innerHTML = `<span class="spinner"></span> Signing in...`;
    btn.disabled = true;

    try {
      const payload = {
        usernameOrEmail: document.getElementById("login-identity").value.trim(),
        password: document.getElementById("login-password").value
      };

      const res = await api("/api/auth/login", "POST", payload);
      if (res.success && res.token) {
        state.token = res.token;
        state.user = res.user;
        localStorage.setItem("session_token", res.token);
        updateUserGreeting();
        showAlert(`Welcome back, ${res.user.fullName || res.user.username}!`, "success");
        showPage("dashboard");
      }
    } catch (err) {
      // Alert handled
    } finally {
      btn.innerHTML = `🔓 Sign In to Student Dashboard`;
      btn.disabled = false;
    }
  });

  // Add Goal Form
  document.getElementById("form-add-goal").addEventListener("submit", async (e) => {
    e.preventDefault();
    const inp = document.getElementById("new-goal-text");
    const title = inp.value.trim();
    if (!title) return;
    try {
      await api("/api/goals/add", "POST", { title });
      inp.value = "";
      loadDashboard();
    } catch (e) {}
  });

  // Clear Activity Feed
  document.getElementById("btn-clear-activity").addEventListener("click", async () => {
    if (confirm("Are you sure you want to clear your activity history?")) {
      await api("/api/activity/clear", "POST");
      loadDashboard();
    }
  });

  // AI Tutor Chat Form
  document.getElementById("form-chat").addEventListener("submit", async (e) => {
    e.preventDefault();
    const inp = document.getElementById("chat-input-text");
    const query = inp.value.trim();
    if (!query) return;
    inp.value = "";
    sendChatMessage(query);
  });

  // Clear Chat History
  document.getElementById("btn-clear-chat").addEventListener("click", () => {
    const ch = document.getElementById("chat-history");
    ch.innerHTML = `
      <div class="chat-msg assistant">
        👋 Chat history cleared. What would you like to learn next?
      </div>
    `;
  });

  // Quiz Config Form
  document.getElementById("form-quiz-config").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-gen-quiz");
    btn.innerHTML = `<span class="spinner"></span> Generating questions with Gemini AI...`;
    btn.disabled = true;

    try {
      const topic = document.getElementById("quiz-topic").value.trim();
      const difficulty = document.getElementById("quiz-diff").value;
      const count = document.getElementById("quiz-count").value;

      const quiz = await api("/api/quiz/generate", "POST", {
        topic, difficulty, numQuestions: count
      });

      renderActiveQuiz(quiz);
    } catch (err) {
      // Handled
    } finally {
      btn.innerHTML = `🎯 Generate Practice Quiz`;
      btn.disabled = false;
    }
  });

  // Quiz Submit Form
  document.getElementById("form-quiz-answers").addEventListener("submit", async (e) => {
    e.preventDefault();
    submitQuizAnswers();
  });

  // PDF Ask Form
  document.getElementById("form-pdf-ask").addEventListener("submit", async (e) => {
    e.preventDefault();
    const qInp = document.getElementById("pdf-question-input");
    const q = qInp.value.trim();
    if (!q) return;
    qInp.value = "";
    runPdfAction("ask", q);
  });

  // Exam Guide Form
  document.getElementById("form-exam-guide").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-gen-exam");
    btn.innerHTML = `<span class="spinner"></span> Building exam master plan...`;
    btn.disabled = true;

    try {
      const examName = document.getElementById("exam-name").value.trim();
      const examDays = document.getElementById("exam-days").value;
      const examType = document.getElementById("exam-type").value;
      const topics = document.getElementById("exam-topics").value.trim();

      const res = await api("/api/exam/generate", "POST", {
        examName, examDays, examType, challengingTopics: topics
      });

      const sec = document.getElementById("exam-result-section");
      const out = document.getElementById("exam-guide-output");
      out.textContent = res.guide;
      sec.style.display = "block";

      document.getElementById("btn-download-exam").onclick = () => {
        downloadText(res.guide, `Exam_Guide_${examName.replace(/\s+/g, "_")}.md`);
      };

      sec.scrollIntoView({ behavior: "smooth" });
    } catch (e) {
      // Handled
    } finally {
      btn.innerHTML = `🚀 Generate My Exam Revision Master Plan`;
      btn.disabled = false;
    }
  });

  // LinkedIn Audit Button
  document.getElementById("btn-run-li-audit").addEventListener("click", async () => {
    const btn = document.getElementById("btn-run-li-audit");
    btn.innerHTML = `<span class="spinner"></span> Analyzing profile against tech recruiter benchmarks...`;
    btn.disabled = true;

    try {
      const headline = document.getElementById("li-headline").value.trim();
      const summary = document.getElementById("li-summary").value.trim();
      const skills = document.getElementById("li-skills").value.trim();
      const targetRole = document.getElementById("li-role").value.trim() || "Data Science & AI Intern";
      const profileUrl = document.getElementById("li-url").value.trim();
      const interest = state.user?.interests || "Data Science & AI";

      const res = await api("/api/linkedin/audit", "POST", {
        headline, summary, skills, targetRole, interest, profileUrl
      });

      renderLinkedInAudit(res.audit);
    } catch (e) {
      // Handled
    } finally {
      btn.innerHTML = `✨ Run AI Recruiter Audit & Headline Optimizer`;
      btn.disabled = false;
    }
  });

  // Internships filter inputs
  ["intern-search", "intern-category", "intern-mode"].forEach(id => {
    document.getElementById(id).addEventListener("input", debounce(loadInternships, 300));
  });

  // Add external app form
  document.getElementById("form-add-external-app").addEventListener("submit", async (e) => {
    e.preventDefault();
    const company = document.getElementById("ext-comp").value.trim();
    const role = document.getElementById("ext-role").value.trim();
    const location = document.getElementById("ext-loc").value.trim();
    const stipend = document.getElementById("ext-stip").value.trim();
    const status = document.getElementById("ext-status").value;

    try {
      await api("/api/internships/track", "POST", { company, role, location, stipend, status });
      showAlert("Application added to tracker!", "success");
      document.getElementById("form-add-external-app").reset();
      loadInternships();
    } catch (e) {}
  });

  // Update Profile Form
  document.getElementById("form-update-profile").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector("button[type=submit]");
    btn.innerHTML = `<span class="spinner"></span> Saving profile...`;
    btn.disabled = true;

    try {
      const payload = {
        fullName: document.getElementById("prof-fullname").value.trim(),
        college: document.getElementById("prof-college").value.trim(),
        branch: document.getElementById("prof-branch").value.trim(),
        targetRole: document.getElementById("prof-role").value.trim(),
        interests: document.getElementById("prof-interests").value,
        linkedinUrl: document.getElementById("prof-linkedin").value.trim(),
        skills: document.getElementById("prof-skills").value.trim()
      };

      const res = await api("/api/user/profile", "POST", payload);
      if (res.success && res.user) {
        state.user = res.user;
        updateUserGreeting();
        showAlert(res.message, "success");
      }
    } catch (e) {
      // Handled
    } finally {
      btn.innerHTML = `💾 Save Profile Changes`;
      btn.disabled = false;
    }
  });

  // Logout button
  document.getElementById("btn-logout").addEventListener("click", logout);
}

// --- DASHBOARD LOADER ---
async function loadDashboard() {
  if (!state.user) return;

  // Set Profile banner
  const name = state.user.fullName || state.user.username || "Scholar";
  document.getElementById("dash-fullname").textContent = name;
  document.getElementById("dash-subtext").textContent = `🏛️ ${state.user.college || "University"} • 🎯 ${state.user.interests || "Data Science & AI"}`;

  try {
    const data = await api("/api/dashboard");

    // Stats
    document.getElementById("stat-ai-count").textContent = data.aiCount || 0;
    document.getElementById("stat-quiz-count").textContent = data.quizCount || 0;
    document.getElementById("stat-avg-score").textContent = data.avgQuizScore > 0 ? `${data.avgQuizScore}%` : "—";
    document.getElementById("stat-pdf-count").textContent = data.pdfCount || 0;
    document.getElementById("stat-intern-count").textContent = data.internshipCount || 0;

    // Goals checklist
    const goals = data.goals || [];
    const completedCount = goals.filter(g => g.completed).length;
    const totalCount = Math.max(1, goals.length);
    const pct = Math.round((completedCount / totalCount) * 100);

    document.getElementById("goals-progress-bar").style.width = `${pct}%`;
    document.getElementById("goals-progress-caption").textContent = `Weekly Target Progress: ${completedCount} of ${totalCount} milestones completed (${pct}%)`;

    const checklistContainer = document.getElementById("goals-checklist");
    checklistContainer.innerHTML = "";
    goals.forEach(g => {
      const lbl = document.createElement("label");
      lbl.style.cssText = "display: flex; align-items: center; gap: 8px; font-size: 0.9rem; cursor: pointer;";
      lbl.innerHTML = `
        <input type="checkbox" ${g.completed ? "checked" : ""} style="cursor: pointer;">
        <span style="${g.completed ? "text-decoration: line-through; opacity: 0.7;" : ""}">${escapeHtml(g.title)}</span>
      `;
      const chk = lbl.querySelector("input");
      chk.addEventListener("change", async () => {
        await api("/api/goals/toggle", "POST", { goalId: g.id, completed: chk.checked });
        loadDashboard();
      });
      checklistContainer.appendChild(lbl);
    });

    // Activity Feed
    const feed = document.getElementById("activity-feed");
    feed.innerHTML = "";
    const activities = data.activities || [];
    if (activities.length === 0) {
      feed.innerHTML = `<div class="alert alert-info">👋 No activities logged yet. Ask the AI Tutor a question, take a quiz, or upload a PDF to see your progress recorded here!</div>`;
    } else {
      activities.forEach(a => {
        let badgeClass = "badge-ai";
        if (a.activityType === "Quiz") badgeClass = "badge-quiz";
        else if (a.activityType === "PDF Study") badgeClass = "badge-pdf";
        else if (a.activityType === "Exam Guide") badgeClass = "badge-exam";
        else if (a.activityType === "Career") badgeClass = "badge-career";

        const scoreBadge = (a.score !== null && a.score !== undefined) ? ` • Score: ${Math.round(a.score)}%` : "";

        const card = document.createElement("div");
        card.className = "nx-expander";
        card.innerHTML = `
          <div class="nx-expander-header" onclick="toggleExpander(this)">
            <span>${escapeHtml(a.title)} <span style="font-size:0.75rem; color:#94a3b8; font-weight:normal;">(${escapeHtml(a.createdAt ? a.createdAt.slice(0,16) : "")})</span></span>
            <span>▶</span>
          </div>
          <div class="nx-expander-body" style="display: none;">
            <div style="margin-bottom: 8px;">
              <span class="activity-badge ${badgeClass}">${escapeHtml(a.activityType)}</span>${scoreBadge}
            </div>
            ${a.inputText ? `<div style="margin-bottom: 6px;"><strong>Query / Input:</strong><br><blockquote style="margin: 4px 0; border-left: 3px solid #8b5cf6; padding-left: 8px; color: #cbd5e1;">${escapeHtml(a.inputText)}</blockquote></div>` : ""}
            ${a.outputText ? `<div><strong>Details / Response:</strong><br><div style="font-size: 0.85rem; color: #cbd5e1; white-space: pre-wrap;">${escapeHtml(a.outputText.slice(0, 500))}${a.outputText.length > 500 ? "..." : ""}</div></div>` : ""}
          </div>
        `;
        feed.appendChild(card);
      });
    }

  } catch (err) {
    console.error("Dashboard load error", err);
  }
}

// --- AI TUTOR CHAT ---
function sendQuickPrompt(promptText) {
  sendChatMessage(promptText);
}

async function sendChatMessage(query) {
  const ch = document.getElementById("chat-history");

  // Append user message
  const userDiv = document.createElement("div");
  userDiv.className = "chat-msg user";
  userDiv.textContent = query;
  ch.appendChild(userDiv);

  // Append loading assistant message
  const assistDiv = document.createElement("div");
  assistDiv.className = "chat-msg assistant";
  assistDiv.innerHTML = `<span class="spinner"></span> Analyzing and preparing student explanation...`;
  ch.appendChild(assistDiv);
  ch.scrollTop = ch.scrollHeight;

  const level = document.getElementById("chat-level").value;
  const subject = document.getElementById("chat-subject").value;

  try {
    const res = await api("/api/tutor/chat", "POST", { prompt: query, level, subject });
    assistDiv.innerHTML = formatMarkdown(res.reply);
  } catch (e) {
    assistDiv.textContent = "Error: Unable to fetch AI response.";
  }
  ch.scrollTop = ch.scrollHeight;
}

// --- QUIZ LAB ---
function renderActiveQuiz(quiz) {
  state.activeQuiz = quiz;
  const sec = document.getElementById("active-quiz-section");
  const titleEl = document.getElementById("active-quiz-title");
  const listEl = document.getElementById("quiz-questions-list");
  document.getElementById("quiz-result-section").style.display = "none";

  titleEl.textContent = `📋 ${quiz.title || "Practice Quiz"}`;
  listEl.innerHTML = "";

  quiz.questions.forEach((q, idx) => {
    const card = document.createElement("div");
    card.className = "mobile-card";
    card.style.marginBottom = "14px";

    let optHtml = "";
    ["A", "B", "C", "D"].forEach(letter => {
      const optVal = q.options[letter] || "";
      optHtml += `
        <label style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 8px; font-size: 0.9rem; cursor: pointer;">
          <input type="radio" name="quiz_q_${idx}" value="${letter}" style="margin-top: 3px;" required>
          <span><strong>${letter}.</strong> ${escapeHtml(optVal)}</span>
        </label>
      `;
    });

    card.innerHTML = `
      <div style="font-weight: 700; color: #fff; margin-bottom: 10px;">Question ${idx + 1}: ${escapeHtml(q.question)}</div>
      <div>${optHtml}</div>
    `;
    listEl.appendChild(card);
  });

  sec.style.display = "block";
  sec.scrollIntoView({ behavior: "smooth" });
}

async function submitQuizAnswers() {
  if (!state.activeQuiz) return;
  const questions = state.activeQuiz.questions;
  let correctCount = 0;
  const userAnswers = [];

  questions.forEach((q, idx) => {
    const selected = document.querySelector(`input[name="quiz_q_${idx}"]:checked`);
    const ans = selected ? selected.value : "";
    userAnswers.push(ans);
    if (ans === q.answer) correctCount++;
  });

  const total = questions.length;
  const pct = Math.round((correctCount / total) * 100);

  // Submit to server
  try {
    await api("/api/quiz/submit", "POST", {
      title: state.activeQuiz.title,
      correctCount,
      total,
      score: pct
    });
  } catch (e) {}

  // Render Result Card
  const resSec = document.getElementById("quiz-result-section");
  const scoreEl = document.getElementById("quiz-result-score");
  const msgEl = document.getElementById("quiz-result-msg");
  const bdList = document.getElementById("quiz-breakdown-list");

  scoreEl.textContent = `Score: ${correctCount} / ${total} (${pct}%)`;
  msgEl.textContent = pct >= 80 ? "🌟 Outstanding mastery!" : "👍 Good effort! Review explanations below to strengthen your understanding.";

  bdList.innerHTML = "";
  questions.forEach((q, idx) => {
    const uAns = userAnswers[idx];
    const isCorrect = (uAns === q.answer);
    const exp = document.createElement("div");
    exp.className = "nx-expander";
    exp.innerHTML = `
      <div class="nx-expander-header" onclick="toggleExpander(this)">
        <span>${isCorrect ? "✅" : "❌"} Q${idx + 1}: ${escapeHtml(q.question.slice(0, 50))}...</span>
        <span>▼</span>
      </div>
      <div class="nx-expander-body">
        <div style="margin-bottom: 6px;">
          Your Answer: <code>${escapeHtml(uAns || "None")}</code> | 
          <strong style="color: ${isCorrect ? "#34d399" : "#f87171"};">Correct Answer: <code>${escapeHtml(q.answer)}</code></strong>
        </div>
        <div style="font-size: 0.85rem; color: #cbd5e1;"><strong>Explanation:</strong> ${escapeHtml(q.explanation || "No explanation.")}</div>
      </div>
    `;
    bdList.appendChild(exp);
  });

  resSec.style.display = "block";
  resSec.scrollIntoView({ behavior: "smooth" });
}

// --- PDF READER ---
function handlePdfSelected(input) {
  const file = input.files[0];
  if (!file) return;

  const statusMsg = document.getElementById("pdf-status-msg");
  statusMsg.innerHTML = `<span class="spinner"></span> Extracting text from ${escapeHtml(file.name)}...`;

  const reader = new FileReader();
  reader.onload = async (e) => {
    try {
      const base64 = e.target.result;
      const res = await api("/api/pdf/upload", "POST", {
        filename: file.name,
        base64: base64
      });

      state.activePdf = res;
      statusMsg.innerHTML = `✅ Successfully loaded <strong>${escapeHtml(res.filename)}</strong> (${res.wordCount} words)`;
      document.getElementById("pdf-actions-section").style.display = "block";
      document.getElementById("pdf-qa-history").innerHTML = "";
    } catch (err) {
      statusMsg.innerHTML = `<span style="color:#f87171;">❌ ${escapeHtml(err.message)}</span>`;
    }
  };
  reader.readAsDataURL(file);
}

async function runPdfAction(action, question = "") {
  if (!state.activePdf) {
    showAlert("Please upload a PDF document first.", "error");
    return;
  }

  const historyContainer = document.getElementById("pdf-qa-history");
  const card = document.createElement("div");
  card.className = "nx-expander";
  const label = action === "summary" ? "Executive Summary" : (action === "definitions" ? "Key Definitions & Formulas" : (action === "questions" ? "5 Practice Questions" : `Q: ${question}`));

  card.innerHTML = `
    <div class="nx-expander-header" onclick="toggleExpander(this)">
      <span>💬 ${escapeHtml(label)}</span>
      <span>▼</span>
    </div>
    <div class="nx-expander-body">
      <span class="spinner"></span> Generating AI response from document...
    </div>
  `;
  historyContainer.prepend(card);

  try {
    const res = await api("/api/pdf/action", "POST", {
      action,
      pdfText: state.activePdf.text,
      question,
      filename: state.activePdf.filename
    });
    card.querySelector(".nx-expander-body").innerHTML = formatMarkdown(res.answer);
  } catch (err) {
    card.querySelector(".nx-expander-body").textContent = "Error processing document.";
  }
}

// --- LINKEDIN TRACKER ---
async function updateLinkedInScoreMeter() {
  const headline = document.getElementById("li-headline").value.trim();
  const summary = document.getElementById("li-summary").value.trim();
  const skills = document.getElementById("li-skills").value.trim();
  const targetRole = document.getElementById("li-role").value.trim();
  const profileUrl = document.getElementById("li-url").value.trim();

  try {
    const res = await api("/api/linkedin/score", "POST", {
      headline, summary, skills, experience: targetRole, profileUrl
    });

    const score = res.score || 0;
    const bar = document.getElementById("li-score-bar");
    const lbl = document.getElementById("li-score-label");

    bar.style.width = `${score}%`;
    const ratingText = score >= 75 ? "Recruiter Ready!" : (score >= 45 ? "Good Foundation" : "Needs Attention");
    const color = score >= 75 ? "#34d399" : (score >= 45 ? "#f59e0b" : "#f87171");

    lbl.style.color = color;
    lbl.textContent = `${score} / 100 - ${ratingText}`;

    const list = document.getElementById("li-checkpoints-list");
    list.innerHTML = "";
    (res.feedbackItems || []).forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      list.appendChild(li);
    });
  } catch (e) {}
}

function renderLinkedInAudit(auditRaw) {
  const resSec = document.getElementById("li-audit-result");
  try {
    // Extract JSON if model wrapped in code fence
    let cleaned = auditRaw.trim();
    if (cleaned.startsWith("```")) {
      cleaned = cleaned.replace(/^```(?:json)?\s*|\s*```$/gi, "").trim();
    }
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    const audit = JSON.parse(cleaned.slice(start, end + 1));

    // 1. Headline Options
    const hContainer = document.getElementById("li-headlines-container");
    hContainer.innerHTML = "";
    (audit.headline_options || []).forEach(h => {
      const div = document.createElement("div");
      div.className = "alert alert-info";
      div.style.marginBottom = "8px";
      div.innerHTML = `📌 <strong>${escapeHtml(h)}</strong>`;
      hContainer.appendChild(div);
    });

    // 2. Summary
    document.getElementById("li-summary-card").innerHTML = escapeHtml(audit.improved_summary || "").replace(/\n/g, "<br>");

    // 3. Keywords
    const kContainer = document.getElementById("li-keywords-container");
    kContainer.innerHTML = "";
    (audit.recommended_keywords || []).forEach(kw => {
      const tag = document.createElement("span");
      tag.className = "skill-tag";
      tag.textContent = kw;
      kContainer.appendChild(tag);
    });

    // 4. Improvements
    const impList = document.getElementById("li-improvements-list");
    impList.innerHTML = "";
    (audit.top_improvements || []).forEach(tip => {
      const li = document.createElement("li");
      li.textContent = tip;
      impList.appendChild(li);
    });

    resSec.style.display = "block";
    resSec.scrollIntoView({ behavior: "smooth" });
  } catch (err) {
    showAlert("Received audit response. Rendering formatted output...", "info");
    resSec.style.display = "block";
    document.getElementById("li-summary-card").textContent = auditRaw;
  }
}

// --- INTERNSHIPS ---
async function loadInternships() {
  const q = document.getElementById("intern-search").value.trim();
  const category = document.getElementById("intern-category").value;
  const mode = document.getElementById("intern-mode").value;

  try {
    const list = await api(`/api/internships?category=${encodeURIComponent(category)}&mode=${encodeURIComponent(mode)}&q=${encodeURIComponent(q)}`);
    document.getElementById("internships-count-label").textContent = `Found ${list.length} curated internships:`;

    const container = document.getElementById("internships-list");
    container.innerHTML = "";

    list.forEach(item => {
      const card = document.createElement("div");
      card.className = "internship-card";

      const skillsHtml = (item.skills || []).map(s => `<span class="skill-tag">${escapeHtml(s)}</span>`).join(" ");

      card.innerHTML = `
        <div class="internship-header">
          <div>
            <div style="font-size: 1.5rem; margin-bottom: 4px;">${item.emoji || "💼"}</div>
            <h4 class="internship-title">${escapeHtml(item.title)}</h4>
            <div class="internship-company">🏢 ${escapeHtml(item.company)} • 📍 ${escapeHtml(item.location)} (${escapeHtml(item.mode)})</div>
          </div>
          <div style="text-align: right;">
            <span class="free-badge" style="background: rgba(99,102,241,0.2); color:#c7d2fe; border-color:#6366f1;">💰 ${escapeHtml(item.stipend)}</span>
            <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 4px;">⏳ ${escapeHtml(item.duration)}</div>
          </div>
        </div>
        <p style="margin: 8px 0; font-size: 0.88rem; color: #cbd5e1 !important;">${escapeHtml(item.description)}</p>
        <div style="margin-bottom: 12px;">${skillsHtml}</div>
        <div class="grid-3" style="margin-top: 10px;">
          <a href="${item.applyUrl}" target="_blank" class="btn btn-primary" style="background:#2563eb; color:#fff;">🌐 Apply on Portal</a>
          <button class="btn btn-primary btn-gen-pitch" data-id="${item.id}">✉️ Generate AI Pitch</button>
          <button class="btn btn-secondary btn-save-track" data-id="${item.id}">🔖 Save to Tracker</button>
        </div>
      `;

      card.querySelector(".btn-gen-pitch").addEventListener("click", () => generatePitch(item));
      card.querySelector(".btn-save-track").addEventListener("click", () => trackInternship(item));

      container.appendChild(card);
    });

    // Also load tracked applications
    loadTrackedInternships();

  } catch (e) {
    console.error("Internships load error", e);
  }
}

async function generatePitch(item) {
  const pSec = document.getElementById("pitch-output-section");
  const pBox = document.getElementById("pitch-text-box");
  const pTitle = document.getElementById("pitch-output-title");

  pTitle.textContent = `✉️ Customized Application Pitch for ${item.company} (${item.title})`;
  pBox.innerHTML = `<span class="spinner"></span> Writing high-converting application pitch...`;
  pSec.style.display = "block";
  pSec.scrollIntoView({ behavior: "smooth" });

  try {
    const res = await api("/api/internships/pitch", "POST", { internshipId: item.id });
    pBox.textContent = res.pitch;
    document.getElementById("btn-copy-pitch").onclick = () => {
      navigator.clipboard.writeText(res.pitch);
      showAlert("Pitch copied to clipboard!", "success");
    };
  } catch (e) {
    pBox.textContent = "Error generating pitch.";
  }
}

async function trackInternship(item) {
  try {
    await api("/api/internships/track", "POST", {
      company: item.company,
      role: item.title,
      location: item.location,
      stipend: item.stipend,
      status: "Interested",
      notes: item.description ? item.description.slice(0, 100) : ""
    });
    showAlert(`Saved ${item.title} to your tracker!`, "success");
    loadTrackedInternships();
  } catch (e) {}
}

async function loadTrackedInternships() {
  if (!state.user) return;
  const container = document.getElementById("tracked-internships-list");
  if (!container) return;

  try {
    const tracked = await api("/api/internships/tracked");
    container.innerHTML = "";
    if (tracked.length === 0) {
      container.innerHTML = `<div class="alert alert-info">You haven't saved any internships to your tracker yet. Click '🔖 Save to Tracker' on any listing in the Browse tab!</div>`;
      return;
    }

    tracked.forEach(t => {
      const card = document.createElement("div");
      card.className = "nx-expander";
      card.innerHTML = `
        <div class="nx-expander-header" onclick="toggleExpander(this)">
          <span><strong>${escapeHtml(t.role)}</strong> at ${escapeHtml(t.company)} — Status: <span style="color:#38bdf8;">${escapeHtml(t.status)}</span></span>
          <span>▼</span>
        </div>
        <div class="nx-expander-body">
          <div style="margin-bottom: 8px;"><strong>Location:</strong> ${escapeHtml(t.location)} | <strong>Stipend:</strong> ${escapeHtml(t.stipend)} | <strong>Saved:</strong> ${escapeHtml(t.appliedAt ? t.appliedAt.slice(0,10) : "")}</div>
          <div class="grid-2" style="margin-top: 10px;">
            <div>
              <label style="font-size: 0.8rem; color: #94a3b8;">Update Status:</label>
              <select class="form-control status-select" style="margin-top: 4px;">
                ${["Interested", "Applied", "Under Review", "Interview Scheduled", "Offer Received"].map(s => `<option value="${s}" ${s === t.status ? "selected" : ""}>${s}</option>`).join("")}
              </select>
            </div>
            <div style="display: flex; align-items: flex-end;">
              <button class="btn btn-secondary btn-del-track" style="color: #f87171; border-color: #ef4444;">🗑️ Remove from Tracker</button>
            </div>
          </div>
        </div>
      `;

      card.querySelector(".status-select").addEventListener("change", async (e) => {
        await api("/api/internships/track", "POST", {
          company: t.company,
          role: t.role,
          location: t.location,
          stipend: t.stipend,
          status: e.target.value
        });
        showAlert("Application status updated!", "success");
      });

      card.querySelector(".btn-del-track").addEventListener("click", async () => {
        if (confirm(`Remove ${t.role} from tracker?`)) {
          await api("/api/internships/delete", "POST", { id: t.id });
          loadTrackedInternships();
        }
      });

      container.appendChild(card);
    });

  } catch (e) {}
}

// --- PROFILE LOADER ---
function loadProfile() {
  if (!state.user) return;
  document.getElementById("prof-fullname").value = state.user.fullName || "";
  document.getElementById("prof-username").value = state.user.username || "";
  document.getElementById("prof-email").value = state.user.email || "";
  document.getElementById("prof-college").value = state.user.college || "";
  document.getElementById("prof-branch").value = state.user.branch || "";
  document.getElementById("prof-role").value = state.user.targetRole || "AI & Data Science Intern";
  document.getElementById("prof-interests").value = state.user.interests || "Data Science & AI";
  document.getElementById("prof-linkedin").value = state.user.linkedinUrl || "";
  document.getElementById("prof-skills").value = state.user.skills || "Python, Machine Learning, SQL";

  // Pre-fill linkedin tab as well
  document.getElementById("li-url").value = state.user.linkedinUrl || "";
  document.getElementById("li-role").value = state.user.targetRole || "AI & Data Science Intern";
  document.getElementById("li-skills").value = state.user.skills || "Python, Machine Learning, SQL";
}

// --- HELPERS ---
function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formatMarkdown(text) {
  if (!text) return "";
  let html = escapeHtml(text);
  // Bold **text**
  html = html.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  // Italic *text*
  html = html.replace(/\*(.*?)\*/g, "<em>$1</em>");
  // Code `text`
  html = html.replace(/`([^`]+)`/g, "<code style='background:rgba(255,255,255,0.1); padding:2px 4px; border-radius:4px;'>$1</code>");
  // Linebreaks
  html = html.replace(/\n/g, "<br>");
  return html;
}

function downloadText(content, filename) {
  const blob = new Blob([content], { type: "text/markdown;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function debounce(fn, delay) {
  let timer;
  return function(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}
