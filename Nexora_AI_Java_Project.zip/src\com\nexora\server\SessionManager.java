package com.nexora.server;

import com.nexora.db.Database;
import com.nexora.model.User;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SessionManager {
    private static final Map<String, Integer> SESSIONS = new ConcurrentHashMap<>();

    public static String createSession(int userId) {
        String token = UUID.randomUUID().toString();
        SESSIONS.put(token, userId);
        return token;
    }

    public static User getUser(String token) {
        if (token == null || token.isBlank()) return null;
        Integer userId = SESSIONS.get(token);
        if (userId == null) return null;
        return Database.getUserById(userId);
    }

    public static void removeSession(String token) {
        if (token != null) {
            SESSIONS.remove(token);
        }
    }
}
