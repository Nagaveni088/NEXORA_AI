package com.nexora.model;

import java.util.ArrayList;
import java.util.List;

public class Quiz {
    private String title;
    private List<QuizQuestion> questions;
    private String error;

    public Quiz() {
        this.questions = new ArrayList<>();
    }

    public Quiz(String title, List<QuizQuestion> questions) {
        this.title = title;
        this.questions = questions != null ? questions : new ArrayList<>();
    }

    public Quiz(String error) {
        this.error = error;
        this.title = "Quiz";
        this.questions = new ArrayList<>();
    }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public List<QuizQuestion> getQuestions() { return questions; }
    public void setQuestions(List<QuizQuestion> questions) { this.questions = questions; }

    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
}
